<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . "/../backend/connect.php";
session_start();

if (!isset($_SESSION['user_id'])) {
    die("Not logged in");
}

$user_id = $_SESSION['user_id'];
echo "<h1>Debug Transactions</h1>";
echo "<p>User ID: $user_id</p>";

// Fetch raw transactions
$stmt = $conn->prepare("SELECT * FROM transactions WHERE user_id = ? ORDER BY created_at DESC");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$res = $stmt->get_result();

echo "<table border='1' cellpadding='5'>";
echo "<tr><th>ID</th><th>Category</th><th>Amount</th><th>Method</th><th>Status</th><th>Mpesa Ref</th><th>Created At</th></tr>";

while ($row = $res->fetch_assoc()) {
    echo "<tr>";
    echo "<td>" . $row['id'] . "</td>";
    echo "<td>'" . $row['category'] . "'</td>"; // Single quotes to see whitespace
    echo "<td>" . $row['amount'] . "</td>";
    echo "<td>" . $row['method'] . "</td>";
    echo "<td>" . $row['status'] . "</td>";
    echo "<td>" . $row['mpesa_ref'] . "</td>";
    echo "<td>" . $row['created_at'] . "</td>";
    echo "</tr>";
}
echo "</table>";

// Check User Package
$stmt2 = $conn->prepare("SELECT package FROM users WHERE id = ?");
$stmt2->bind_param("i", $user_id);
$stmt2->execute();
$res2 = $stmt2->get_result();
$user = $res2->fetch_assoc();
echo "<h2>User Profile Package</h2>";
echo "<p>Current Package: " . ($user['package'] ?? 'NULL') . "</p>";

?>
