<?php
require_once __DIR__ . '/../backend/mpesa/callback_handler.php';
handle_mpesa_callback($conn);