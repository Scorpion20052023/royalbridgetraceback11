<?php
session_start();
require_once __DIR__ . "/../backend/connect.php";

header("Content-Type: application/json");

if (!isset($_SESSION["user_id"])) {
    echo json_encode([]);
    exit;
}

$user_id = $_SESSION["user_id"];

// Fetch uploads from the specific uploads table
$stmt = $conn->prepare("
    SELECT file_name, amount, created_at 
    FROM whatsapp_uploads 
    WHERE user_id = ? 
    ORDER BY id DESC
");

$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

$uploads = [];
while ($row = $result->fetch_assoc()) {
    $uploads[] = [
        "filename" => $row["file_name"],
        "amount" => $row["amount"],
        "created_at" => $row["created_at"]
    ];
}

echo json_encode($uploads);
?>
