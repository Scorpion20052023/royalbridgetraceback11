<?php
session_start();
require_once __DIR__ . "/../backend/connect.php";

header("Content-Type: application/json");

if (!isset($_SESSION['user_id'])) {
    echo json_encode([]);
    exit;
}

$user_id = $_SESSION['user_id'];
$history = [];

// 1. Fetch Invested (Principal) - All investments ever made
// These are the "Confirmed" records (money OUT)
$stmt = $conn->prepare("SELECT amount, duration_days, created_at FROM investments WHERE user_id = ? ORDER BY id DESC");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) {
    $history[] = [
        "type" => "investment",
        "amount" => $row['amount'],
        "days" => $row['duration_days'],
        "created_at" => $row['created_at'],
        "status" => "Confirmed", // Initial state
        "prefix" => "-" // Money leaving wallet
    ];
}
$stmt->close();

// 2. Fetch Matured (Returns) - From new table
// These are the "Matured" records (money IN)
$stmt2 = $conn->prepare("SELECT amount, duration_days, matured_at as created_at FROM matured_investments WHERE user_id = ? ORDER BY id DESC");
$stmt2->bind_param("i", $user_id);
$stmt2->execute();
$res2 = $stmt2->get_result();
while ($row = $res2->fetch_assoc()) {
    $history[] = [
        "type" => "return",
        "amount" => $row['amount'],
        "days" => $row['duration_days'],
        "created_at" => $row['created_at'],
        "status" => "Matured",
        "prefix" => "+" // Money entering wallet
    ];
}
$stmt2->close();

// Sort by date desc
usort($history, function($a, $b) {
    return strtotime($b['created_at']) - strtotime($a['created_at']);
});

echo json_encode($history);
?>
