<?php
require_once 'C:/xampp/htdocs/RoyalBridge/RoyalBridge/backend/connect.php';

echo "<h1>Debug Referrals</h1>";

// 1. Dump Users
echo "<h2>Users Table (Last 10)</h2>";
$users = $conn->query("SELECT id, username, email FROM users ORDER BY id DESC LIMIT 10");
echo "<table border='1'><tr><th>ID</th><th>Username</th><th>Email</th></tr>";
while($u = $users->fetch_assoc()) {
    echo "<tr><td>{$u['id']}</td><td>{$u['username']}</td><td>{$u['email']}</td></tr>";
}
echo "</table>";

// 2. Dump Referrals
echo "<h2>Referrals Table (All)</h2>";
$refs = $conn->query("SELECT * FROM referrals");
echo "<table border='1'><tr><th>ID</th><th>Referrer ID</th><th>Referred User ID</th><th>Status</th><th>Created At</th></tr>";
while($r = $refs->fetch_assoc()) {
    echo "<tr><td>{$r['id']}</td><td>{$r['referrer_id']}</td><td>{$r['referred_user_id']}</td><td>{$r['status']}</td><td>{$r['created_at']}</td></tr>";
}
echo "</table>";

// 3. Test Query Logic (Simulating for all referrers found)
echo "<h2>Test Query Results</h2>";
$referrers = $conn->query("SELECT DISTINCT referrer_id FROM referrals");
while($ref = $referrers->fetch_assoc()) {
    $rId = $ref['referrer_id'];
    echo "<h3>Results for Referrer ID: $rId</h3>";
    
    $sql = "
        SELECT 
            u.username, 
            r.status,
            r.created_at
        FROM referrals r
        JOIN users u ON r.referred_user_id = u.id
        WHERE r.referrer_id = $rId
    ";
    
    $res = $conn->query($sql);
    if($res->num_rows > 0) {
        while($row = $res->fetch_assoc()) {
            echo "Found: {$row['username']} - {$row['status']} - {$row['created_at']}<br>";
        }
    } else {
        echo "Query returned NO results for this referrer.<br>";
    }
}
?>
