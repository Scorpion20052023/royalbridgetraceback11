<?php
require_once __DIR__ . "/../../backend/connect.php";

$res = $conn->query("SELECT file_name FROM daily_uploads ORDER BY id DESC LIMIT 1");

if ($row = $res->fetch_assoc()) {
    echo json_encode([
        "status" => "success",
        "image_url" => "../uploads/daily_products/" . $row["file_name"]
    ]);
} else {
    echo json_encode(["status" => "empty"]);
}
