<?php
require_once __DIR__ . "/../backend/connect.php";

echo "Attempting to fix broken investment transactions...\n";

// Fix records where category is empty and ref looks like 'X-day'
// These are the investment_principal records that failed to insert correctly due to the type mismatch
$sqlFix = "UPDATE transactions 
           SET category='investment_principal' 
           WHERE category='' 
           AND mpesa_ref LIKE '%-day'";

if ($conn->query($sqlFix) === TRUE) {
    echo "Fixed " . $conn->affected_rows . " broken investment records.\n";
} else {
    echo "Error updating records: " . $conn->error . "\n";
}

$conn->close();
?>
