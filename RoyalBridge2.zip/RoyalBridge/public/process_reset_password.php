<?php
session_start();
require_once __DIR__ . '/../backend/connect.php';

header('Content-Type: application/json');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email    = trim($_POST['email']);
    $token    = trim($_POST['token']);
    $password = $_POST['password'];

    // 1. Validate Token
    $stmt = $conn->prepare("SELECT id, expires_at FROM password_resets WHERE email=? AND token=? ORDER BY created_at DESC LIMIT 1");
    $stmt->bind_param("ss", $email, $token);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($row = $res->fetch_assoc()) {
        // Check expiration
        if (strtotime($row['expires_at']) < time()) {
            echo json_encode(['ok' => false, 'error' => 'Token expired.']);
            exit;
        }

        // 2. Update User Password
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $update = $conn->prepare("UPDATE users SET password=? WHERE email=?");
        $update->bind_param("ss", $hash, $email);
        
        if ($update->execute()) {
            // 3. Delete Token
            $del = $conn->prepare("DELETE FROM password_resets WHERE email=?");
            $del->bind_param("s", $email);
            $del->execute();

            echo json_encode(['ok' => true, 'message' => 'Password changed successfully.']);
        } else {
            echo json_encode(['ok' => false, 'error' => 'Database error during update.']);
        }
    } else {
        echo json_encode(['ok' => false, 'error' => 'Invalid token or email.']);
    }
}
?>
