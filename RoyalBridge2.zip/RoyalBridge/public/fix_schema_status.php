<?php
require_once __DIR__ . "/../backend/connect.php";

echo "Attempting to fix status schema...\n";

// Add 'confirmed' and 'matured' to status ENUM
// Existing: 'pending','success','failed'
$sqlAttr = "ALTER TABLE transactions MODIFY COLUMN status ENUM('pending','success','failed','confirmed','matured') NOT NULL DEFAULT 'pending'";

if ($conn->query($sqlAttr) === TRUE) {
    echo "Schema updated successfully. Added confirmed/matured to status ENUM.\n";
} else {
    echo "Error updating schema: " . $conn->error . "\n";
}

// Optional: Fix old blank statuses that might have been caused by truncation
$conn->query("UPDATE transactions SET status='success' WHERE status=''");

$conn->close();
?>
