<?php
session_start();
// Prevent any HTML error output from breaking JSON
error_reporting(0);
ini_set('display_errors', 0);

require_once __DIR__ . '/../backend/connect.php';
require_once __DIR__ . '/transactions/record_transaction.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit;
}

$user_id = $_SESSION['user_id'];
$token_name = $_POST['token_name'] ?? ''; // e.g., "Verification Code"
$amount     = floatval($_POST['amount'] ?? 0);

if (empty($token_name) || $amount <= 0) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid Request']);
    exit;
}

try {
    $conn->begin_transaction();

    // 1. Fetch User Balance & Email
    $stmt = $conn->prepare("SELECT u.email, w.deposit_balance FROM users u JOIN wallets w ON u.id = w.user_id WHERE u.id = ? FOR UPDATE");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $res = $stmt->get_result();
    $user = $res->fetch_assoc();

    if (!$user) throw new Exception("User not found.");
    
    // Admin Bypass
    $isAdmin = isset($_SESSION['admin_id']);
    
    if (!$isAdmin && $user['deposit_balance'] < $amount) {
        throw new Exception("Insufficient deposit funds.");
    }

    // 2. Deduct Funds (Only if not admin)
    if (!$isAdmin) {
        $new_bal = $user['deposit_balance'] - $amount;
        $up = $conn->prepare("UPDATE wallets SET deposit_balance = ? WHERE user_id = ?");
        $up->bind_param("di", $new_bal, $user_id);
        if (!$up->execute()) throw new Exception("Failed to update wallet.");
    }

    // 3. Generate Token
    // 5-digit code
    $code = rand(10000, 99999);

    // 4. Save Token
    $ins = $conn->prepare("INSERT INTO withdrawal_tokens (user_id, token_code, token_type, cost) VALUES (?, ?, ?, ?)");
    $ins->bind_param("issd", $user_id, $code, $token_name, $amount);
    if (!$ins->execute()) throw new Exception("Failed to generate token.");

    // 5. Record Transaction
    // Category: token_purchase
    record_transaction($conn, $user_id, 'token_purchase', -$amount, 'system', 'success', $token_name);

    $conn->commit();

    // 6. Email User & Logging
    // In local XAMPP, mail() usually fails or does nothing. 
    // We will Log it and ALSO return it in the message for testing convenience.
    
    $subject = "Your RoyalBridge Token: $token_name";
    $message = "Hello,\n\nYour purchase of $token_name was successful.\n\nYour Token Code is: $code\n\nDo not share this code. Use it for withdrawals.\n\nRegards,\nRoyalBridge Team";
    $headers = "From: no-reply@royalbridge.com";
    
    // Suppress warnings to prevent JSON breakage
    $mailSent = @mail($user['email'], $subject, $message, $headers);

    // Logging
    // Create logs dir if not exists (although we ran mkdir, good to be safe)
    $logDir = __DIR__ . '/../logs';
    if (!is_dir($logDir)) { @mkdir($logDir, 0777, true); }
    
    $logFile = $logDir . '/tokens.log';
    $logEntry = date('c') . " USER:$user_id CODE:$code TYPE:$token_name EMAIL:{$user['email']}" . PHP_EOL;
    @file_put_contents($logFile, $logEntry, FILE_APPEND);

    // Success Message
    // NOTE: For Dev/Testing, we append the code to the message so you can see it immediately.
    $msg = "Token purchased! Check email.";
    if (!$mailSent) {
        $msg .= " (Dev Mode: Output to Popup)";
    }

    echo json_encode([
        'status' => 'success', 
        'message' => $msg, 
        'token_code' => $code, // Return code explicitly for frontend display
        'token_name' => $token_name
    ]);

} catch (Exception $e) {
    if (isset($conn) && $conn->in_transaction) $conn->rollback();
    // Ensure 500? No, dashboard expects JSON.
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>
