<?php
session_start();
require_once __DIR__ . "/../backend/connect.php";

header("Content-Type: application/json");

if (!isset($_SESSION["user_id"])) {
    echo json_encode(["status" => "error", "message" => "Not authenticated"]);
    exit;
}

$user_id = $_SESSION["user_id"];

// Check Service Package
$stmtPkg = $conn->prepare("SELECT package FROM users WHERE id = ?");
$stmtPkg->bind_param("i", $user_id);
$stmtPkg->execute();
$dataPkg = $stmtPkg->get_result()->fetch_assoc();
if (empty($dataPkg['package']) || $dataPkg['package'] === 'NO PACKAGE') {
    echo json_encode(["status" => "error", "message" => "You need a Service Package to satisfy this request."]);
    exit;
}
$stmtPkg->close();

$views   = intval($_POST["views"] ?? 0);
$amount  = floatval($_POST["amount"] ?? 0);
$phone   = $_POST["phone"] ?? "";

if ($views <= 0 || $amount <= 0) {
    echo json_encode(["status" => "error", "message" => "Invalid views or amount"]);
    exit;
}

if (!isset($_FILES["file"])) {
    echo json_encode(["status" => "error", "message" => "No file uploaded"]);
    exit;
}

$upload_dir = __DIR__ . "/whatsapp_uploads/";
if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);

$file = $_FILES["file"];
$ext  = pathinfo($file["name"], PATHINFO_EXTENSION);
$filename = "WA_" . time() . "_" . rand(1000, 9999) . "." . $ext;

$target = $upload_dir . $filename;

if (!move_uploaded_file($file["tmp_name"], $target)) {
    echo json_encode(["status" => "error", "message" => "Failed to save file"]);
    exit;
}

/* ------------------------------------
   SAVE TO whatsapp_uploads TABLE
------------------------------------ */
$stmt = $conn->prepare("
    INSERT INTO whatsapp_uploads (user_id, file_name, views, amount)
    VALUES (?, ?, ?, ?)
");
$stmt->bind_param("isid", $user_id, $filename, $views, $amount);
$stmt->execute();

/* ------------------------------------
   CREATE TRANSACTION LOG
------------------------------------ */
$description = "Earned {$amount} KES from WhatsApp upload ({$views} views)";

$stmt3 = $conn->prepare("
    INSERT INTO transactions (user_id, category, amount, views, method, status, description)
    VALUES (?, 'whatsapp', ?, ?, 'system', 'success', ?)
");
$stmt3->bind_param("idis", $user_id, $amount, $views, $description);

if (!$stmt3->execute()) {
    echo json_encode([
        "status" => "error",
        "message" => "Transaction insert failed: " . $stmt3->error
    ]);
    exit;
}


/* ------------------------------------
   RESPONSE BACK TO JAVASCRIPT
------------------------------------ */

echo json_encode([
    "status" => "success",
    "filename" => $filename,
    "amount" => $amount,
    "created_at" => date("Y-m-d H:i:s")
]);
exit;
?>
