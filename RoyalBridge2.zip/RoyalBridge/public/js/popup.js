function showPopup(message, type = "success") {
  const popup = document.getElementById("popup");

  // Heading with different colors based on type
  let heading = type === "success" ? "<h2>Success</h2>" : "<h2>Error</h2>";
  popup.innerHTML = heading + "<p>" + message + "</p>";

  popup.className = "popup " + type + " show";
  popup.style.display = "block";

  setTimeout(() => {
    popup.style.display = "none";
    popup.className = "popup " + type;
  }, 4000);
}


// Capital popup (create and remove, avoids container conflicts)
function showCapitalPopup(message, type = "success") {
  const popup = document.createElement("div");
  popup.className = `cap_popup ${type}`;
  popup.innerHTML = `<h2>${type === "success" ? "Success" : "Error"}</h2><p style="margin:0;">${message}</p>`;
  document.body.appendChild(popup);

  // Animate in
  requestAnimationFrame(() => popup.classList.add("show"));

  // Auto-hide and remove
  setTimeout(() => {
    popup.classList.remove("show");
    setTimeout(() => popup.remove(), 200);
  }, 4000);
}