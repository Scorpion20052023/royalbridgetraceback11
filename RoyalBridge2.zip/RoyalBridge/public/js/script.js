const wrapper = document.querySelector('.wrapper');
const registerLink = document.querySelector('.register-link');
const loginLink = document.querySelector('.login-link');

registerLink.onclick = () => {
    wrapper.classList.add('active');
}

loginLink.onclick = () => {
    wrapper.classList.remove('active');
}

// Password Toggle Logic
document.querySelectorAll('.toggle-password').forEach(icon => {
    icon.onclick = function() {
        const targetId = this.getAttribute('data-target');
        const input = document.getElementById(targetId);
        
        if (input.type === 'password') {
            input.type = 'text';
            this.classList.remove('bxs-show');
            this.classList.add('bxs-hide');
        } else {
            input.type = 'password';
            this.classList.remove('bxs-hide');
            this.classList.add('bxs-show');
        }
    };
});