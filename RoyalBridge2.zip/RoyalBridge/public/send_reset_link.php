<?php
session_start();
require_once __DIR__ . '/../backend/connect.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

require_once __DIR__ . '/../backend/phpmailer/Exception.php';
require_once __DIR__ . '/../backend/phpmailer/PHPMailer.php';
require_once __DIR__ . '/../backend/phpmailer/SMTP.php';

header('Content-Type: application/json');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['ok' => false, 'error' => 'Invalid email address']);
        exit;
    }

    // Check if email exists
    $stmt = $conn->prepare("SELECT id, username FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($row = $res->fetch_assoc()) {
        $token = bin2hex(random_bytes(32));
        $expires = date("Y-m-d H:i:s", strtotime('+1 hour'));

        // Save token
        $stmt2 = $conn->prepare("INSERT INTO password_resets (email, token, expires_at) VALUES (?, ?, ?)");
        $stmt2->bind_param("sss", $email, $token, $expires);
        $stmt2->execute();

        // Send Email
        $mail = new PHPMailer(true);

        try {
            // Server settings - fetch from env or use placeholders
            // If credentials are empty, we might just log the link for testing
            $smtpHost = getenv('SMTP_HOST');
            $smtpUser = getenv('SMTP_USER');
            $smtpPass = getenv('SMTP_PASS');
            $smtpPort = getenv('SMTP_PORT') ?: 587;

            $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
            $host = $_SERVER['HTTP_HOST'];
            // dirname might return backslashes on Windows, normalize to forward slashes
            $path = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
            // Remove trailing slash if present
            $path = rtrim($path, '/');
            
            $resetLink = $protocol . $host . $path . "/reset_password.php?token=" . $token . "&email=" . urlencode($email);

            if ($smtpHost && $smtpUser) {
                // $mail->SMTPDebug = SMTP::DEBUG_SERVER; 
                $mail->isSMTP();
                $mail->Host       = $smtpHost;
                $mail->SMTPAuth   = true;
                $mail->Username   = $smtpUser;
                $mail->Password   = $smtpPass;
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port       = $smtpPort;

                $mail->setFrom($smtpUser, 'Royalbridge');
                $mail->addAddress($email);

                $mail->isHTML(true);
                $mail->Subject = 'Reset Your Password';
                $mail->Body    = "
                    <div style='background-color: #0b1120; color: #fff; padding: 20px; font-family: Arial, sans-serif;'>
                        <h2 style='color: #fbbf24;'>Password Reset</h2>
                        <p>Hi " . htmlspecialchars($row['username']) . ",</p>
                        <p>You requested a password reset. Click the button below to reset it:</p>
                        <a href='$resetLink' style='background-color: #7c3aed; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block; margin: 10px 0;'>Reset Password</a>
                        <p style='color: #9ca3af; font-size: 12px;'>If you did not request this, please ignore this email.</p>
                    </div>
                ";

                $mail->send();
                echo json_encode(['ok' => true, 'message' => 'Reset link sent to your email.']);
            } else {
                // Fallback for Localhost Testing without SMTP
                // Log the link to a file so user can test
                $logMsg = "Password Reset Requested for $email. Link: $resetLink" . PHP_EOL;
                file_put_contents(__DIR__ . '/../../logs/email_log.txt', $logMsg, FILE_APPEND);
                
                echo json_encode(['ok' => true, 'message' => 'Simulated: Check logs/email_log.txt for link (No SMTP configured).']);
            }

        } catch (Exception $e) {
            echo json_encode(['ok' => false, 'error' => "Message could not be sent. Mailer Error: {$mail->ErrorInfo}"]);
        }
    } else {
        // Security: Don't reveal if user exists or not, but for UX validation sometimes we verify.
        // Let's return success to prevent enumeration, or specific error if requested.
        // User asked "The email and username should also be bound together", ensuring correct user.
        echo json_encode(['ok' => false, 'error' => 'Email not found in our records.']);
    }
}
?>
