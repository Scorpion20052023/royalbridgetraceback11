<?php
session_start();
require_once __DIR__ . "/../backend/connect.php";

header("Content-Type: application/json");

if (!isset($_SESSION["user_id"])) {
    echo json_encode([]);
    exit;
}

$user_id = $_SESSION["user_id"];

$sql = "
    SELECT amount, views, description, created_at, status
    FROM transactions 
    WHERE user_id = ? AND category = 'whatsapp'
    ORDER BY id DESC
";


$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

$transactions = [];
while($row = $result->fetch_assoc()){
    $transactions[] = $row;
}

echo json_encode(["whatsapp" => $transactions], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
exit;
?>
