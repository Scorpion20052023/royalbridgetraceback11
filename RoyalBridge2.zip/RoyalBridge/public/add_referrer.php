<?php
require_once __DIR__ . '/../backend/connect.php';

// Add referrer_id column to users table if it doesn't exist
try {
    $sql = "ALTER TABLE users ADD COLUMN referrer_id INT DEFAULT NULL";
    if ($conn->query($sql) === TRUE) {
        echo "Successfully added referrer_id column to users table.";
    } else {
        if (strpos($conn->error, "Duplicate column") !== false) {
            echo "Column referrer_id already exists.";
        } else {
            echo "Error adding column: " . $conn->error;
        }
    }
} catch (Exception $e) {
    echo "Exception: " . $e->getMessage();
}

echo "\nDone.";
?>
