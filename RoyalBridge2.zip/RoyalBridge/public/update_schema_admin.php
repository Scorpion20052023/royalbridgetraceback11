<?php
require_once dirname(__DIR__) . '/backend/connect.php';

// Add is_admin column if it doesn't exist
$sql = "SHOW COLUMNS FROM users LIKE 'is_admin'";
$result = $conn->query($sql);

if ($result->num_rows == 0) {
    $alter = "ALTER TABLE users ADD COLUMN is_admin TINYINT(1) DEFAULT 0";
    if ($conn->query($alter) === TRUE) {
        echo "Column 'is_admin' added successfully.<br>";
    } else {
        echo "Error adding column: " . $conn->error . "<br>";
    }
} else {
    echo "Column 'is_admin' already exists.<br>";
}

// Ensure at least one admin exists (fallback for testing)
// Update the user with id=7 (from debug logs) to be admin for testing, or check if 'admin' user exists.
// I'll just leave it default 0 for now, and manually update one user to admin via a separate query or UI for testing.
// Actually, let's make the FIRST user an admin if no admins exist.
$checkAdmin = $conn->query("SELECT id FROM users WHERE is_admin = 1");
if ($checkAdmin->num_rows == 0) {
    // Make user ID 1 (or first available) admin
    $conn->query("UPDATE users SET is_admin = 1 ORDER BY id ASC LIMIT 1");
    echo "Promoted first user to admin for bootstrapping.<br>";
}

echo "Schema update complete.";
?>
