<?php
session_start();
require_once __DIR__ . '/../backend/connect.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Not logged in']);
    exit;
}

$userId = $_SESSION['user_id'];

// Check if user is admin
$stmtAdmin = $conn->prepare("SELECT is_admin FROM users WHERE id = ?");
$stmtAdmin->bind_param("i", $userId);
$stmtAdmin->execute();
$resAdmin = $stmtAdmin->get_result();
$isAdmin = ($rowAdmin = $resAdmin->fetch_assoc()) ? $rowAdmin['is_admin'] : 0;

if ($isAdmin) {
    // Admin sees ALL users
    $sql = "
        SELECT 
            u.id,
            u.username, 
            u.email,
            u.phone, 
            u.package, 
            COALESCE(w.total_deposits, 0.00) as total_deposits,
            'N/A' as referral_status,
            u.created_at as ref_date,
            u.is_admin
        FROM users u
        LEFT JOIN wallets w ON u.id = w.user_id
        ORDER BY u.created_at DESC
    ";
    $stmt = $conn->prepare($sql);
} else {
    // Regular user sees their referrals
    $sql = "
        SELECT 
            u.id,
            u.username, 
            u.email,
            u.phone, 
            u.package, 
            COALESCE(w.total_deposits, 0.00) as total_deposits,
            r.status as referral_status,
            r.created_at as ref_date,
            u.is_admin
        FROM referrals r
        JOIN users u ON r.referred_user_id = u.id
        LEFT JOIN wallets w ON u.id = w.user_id
        WHERE r.referrer_id = ?
        ORDER BY r.created_at DESC
    ";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $userId);
}

$stmt->execute();
$result = $stmt->get_result();

$team = [];
$rank = 1;

while ($row = $result->fetch_assoc()) {
    $team[] = [
        'id' => $row['id'], // Needed for actions
        'rank' => $rank++,
        'name' => $row['username'],
        'email' => $row['email'],
        'phone' => $row['phone'],
        'deposit' => number_format($row['total_deposits'], 2) . ' KES',
        'membership' => $row['package'],
        'status' => $row['referral_status'],
        'ref_date' => date("Y-m-d", strtotime($row['ref_date'])),
        'is_admin' => $row['is_admin']
    ];
}

echo json_encode(['status' => 'success', 'data' => $team, 'is_admin' => (bool)$isAdmin]);
?>
