<?php
require_once __DIR__ . "/../backend/connect.php";

echo "Attempting to fix schema for investments...\n";

// Add investment_principal and investment_return to ENUM
$sqlAttr = "ALTER TABLE transactions MODIFY COLUMN category ENUM('deposit','investment','whatsapp','cashback','aviator','forex','affiliate','withdrawal','service_purchase','investment_principal','investment_return') NOT NULL";

if ($conn->query($sqlAttr) === TRUE) {
    echo "Schema updated successfully. Added investment_principal/return to ENUM.\n";
} else {
    echo "Error updating schema: " . $conn->error . "\n";
}
$conn->close();
?>
