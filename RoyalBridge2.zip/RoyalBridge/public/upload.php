<?php
session_start();
require_once __DIR__ . "/backend/connect.php";

header("Content-Type: application/json");

if (!isset($_SESSION["user_id"])) {
    echo json_encode(["status" => "error", "message" => "Not logged in"]);
    exit;
}

// OPTIONAL: enforce admin
if ($_SESSION["username"] !== "Peter254") {
    echo json_encode(["status" => "error", "message" => "Unauthorized"]);
    exit;
}

if (!isset($_FILES["productImage"])) {
    echo json_encode(["status" => "error", "message" => "No image uploaded"]);
    exit;
}

$uploadDir = __DIR__ . "/uploads/daily/";
if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);

// Delete previous product
$old = $conn->query("SELECT file_name FROM daily_uploads LIMIT 1");
if ($row = $old->fetch_assoc()) {
    @unlink($uploadDir . $row["file_name"]);
}
$conn->query("DELETE FROM daily_uploads");

$file = $_FILES["productImage"];
$ext = pathinfo($file["name"], PATHINFO_EXTENSION);
$filename = "DAILY_" . time() . "." . $ext;

move_uploaded_file($file["tmp_name"], $uploadDir . $filename);

// Save new product
$stmt = $conn->prepare("
    INSERT INTO daily_uploads (file_name, uploaded_by)
    VALUES (?, ?)
");
$stmt->bind_param("si", $filename, $_SESSION["user_id"]);
$stmt->execute();

echo json_encode([
    "status" => "success",
    "image_url" => "./uploads/daily/" . $filename
]);
exit;
