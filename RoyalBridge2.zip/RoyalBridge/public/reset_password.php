<?php
require_once __DIR__ . '/../backend/connect.php';

$token = $_GET['token'] ?? '';
$email = $_GET['email'] ?? '';
$valid = false;

// Basic validation before showing form
if ($token && $email) {
    $stmt = $conn->prepare("SELECT id, expires_at FROM password_resets WHERE email=? AND token=?");
    $stmt->bind_param("ss", $email, $token);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($row = $res->fetch_assoc()) {
        if (strtotime($row['expires_at']) > time()) {
            $valid = true;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Reset Password</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="css/styles.css" rel="stylesheet">
    <link href="css/popup.css" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        body { 
            background: #0b1120; /* Dark blue/black theme */
            display: flex; 
            justify-content: center; 
            align-items: center; 
            height: 100vh;
        }
        .reset-box {
            background: rgba(255, 255, 255, 0.05);
            border: 2px solid #7c3aed; /* Purple border */
            border-radius: 10px;
            padding: 30px;
            width: 400px;
            color: #fff;
            box-shadow: 0 0 20px rgba(124, 58, 237, 0.5);
            backdrop-filter: blur(10px);
        }
        .reset-box h2 {
            color: #fbbf24; /* Yellow heading */
            text-align: center;
            margin-bottom: 20px;
        }
        .input-group {
            margin-bottom: 15px;
            position: relative;
        }
        .input-group input {
            width: 100%;
            background: transparent;
            border: none;
            border-bottom: 2px solid #fff;
            color: #fff;
            padding: 10px 0;
            outline: none;
        }
        .input-group label {
            color: #fff;
        }
        .btn-reset {
            width: 100%;
            padding: 10px;
            background: #7c3aed;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
            font-size: 16px;
            transition: 0.3s;
        }
        .btn-reset:hover {
            background: #fbbf24;
            color: #000;
        }
        .error-msg { color: #ff4d4d; text-align: center; margin-bottom: 15px; }
    </style>
</head>
<body>

<div class="reset-box">
    <?php if ($valid): ?>
        <h2>Reset Password</h2>
        <form id="resetForm">
            <input type="hidden" name="email" value="<?php echo htmlspecialchars($email); ?>">
            <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">
            
            <div class="input-group">
                <input type="password" name="password" id="new_pass" required placeholder="New Password">
            </div>
            <div class="input-group">
                <input type="password" id="confirm_pass" required placeholder="Confirm Password">
            </div>
            
            <button type="submit" class="btn-reset">Update Password</button>
            <p id="msg" style="text-align:center; margin-top:10px;"></p>
        </form>
    <?php else: ?>
        <h2 style="color: #ff4d4d;">Invalid/Expired Link</h2>
        <p style="text-align: center;">This link is invalid or has expired.</p>
        <a href="index.php" style="display:block; text-align:center; margin-top:15px; color:#fbbf24; text-decoration:none;">Go Home</a>
    <?php endif; ?>
</div>

<script>
document.getElementById('resetForm')?.addEventListener('submit', function(e) {
    e.preventDefault();
    const p1 = document.getElementById('new_pass').value;
    const p2 = document.getElementById('confirm_pass').value;
    const msg = document.getElementById('msg');
    
    if(p1 !== p2) {
        msg.style.color = 'red';
        msg.innerText = "Passwords do not match!";
        return;
    }
    
    const formData = new FormData(this);
    
    fetch('process_reset_password.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if(data.ok) {
            msg.style.color = '#fbbf24';
            msg.innerText = "Success! Redirecting...";
            setTimeout(() => window.location.href = 'index.php', 2000);
        } else {
            msg.style.color = 'red';
            msg.innerText = data.error || "Error updating password.";
        }
    })
    .catch(err => {
        msg.style.color = 'red';
        msg.innerText = "Connection error.";
    });
});
</script>

</body>
</html>
