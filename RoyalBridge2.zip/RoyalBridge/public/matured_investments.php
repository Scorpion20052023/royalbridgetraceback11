<?php
require_once __DIR__ . '/../backend/connect.php';
require_once __DIR__ . '/transactions/record_transaction.php';

if (!isset($_SESSION['user_id'])) exit();

$user_id = $_SESSION['user_id'];

$stmt = $conn->prepare("SELECT id, amount, rate, duration_days, start_date 
                        FROM investments 
                        WHERE user_id = ? 
                          AND end_date <= CURDATE() 
                          AND status = 'active'");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        // Profit only
        $profit = $row['amount'] * $row['rate'];

        // Update wallet
        $updateWallet = $conn->prepare("UPDATE wallets 
                                        SET invested_capital = invested_capital + ? 
                                        WHERE user_id = ?");
        $updateWallet->bind_param("di", $profit, $user_id);
        $updateWallet->execute();
        $updateWallet->close();

        // Mark investment as matured
        $updateInv = $conn->prepare("UPDATE investments 
                                     SET status = 'matured' 
                                     WHERE id = ?");
        $updateInv->bind_param("i", $row['id']);
        $updateInv->execute();
        $updateInv->close();

        // Log transaction
        $ref = "{$row['duration_days']}-day";
        record_transaction($conn, $user_id, 'investment_return', $profit, 'system', 'success', $ref);

        // New: Insert into matured_investments table
        $matInst = $conn->prepare("INSERT INTO matured_investments (user_id, investment_id, amount, duration_days) VALUES (?, ?, ?, ?)");
        $matInst->bind_param("iidi", $user_id, $row['id'], $profit, $row['duration_days']);
        $matInst->execute();
        $matInst->close();
    }
}

$stmt->close();
