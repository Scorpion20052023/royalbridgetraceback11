<?php
require_once __DIR__ . '/config/config.php';

$apiUsername = getenv('PAYHERO_API_USERNAME');
$apiPassword = getenv('PAYHERO_API_PASSWORD');
$authToken = getenv('PAYHERO_AUTH_TOKEN');

// If AUTH_TOKEN is not in .env or is empty, uncomment below to generate it
if (empty($authToken)) {
    $authToken = 'Basic ' . base64_encode("$apiUsername:$apiPassword");
}

echo "Using Auth Token: " . substr($authToken, 0, 15) . "...\n";

$ch = curl_init('https://backend.payhero.co.ke/api/v2/channels');
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Authorization: ' . $authToken
]);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$response = curl_exec($ch);
if (curl_errno($ch)) {
    echo 'Error: ' . curl_error($ch);
} else {
    echo "Response:\n" . $response;
}
curl_close($ch);
?>
