<?php
require_once __DIR__ . '/../connect.php';
require_once __DIR__ . '/access_token.php';

function normalize_msisdn(string $phone): string {
    $p = preg_replace('/\D/', '', $phone);
    if (strpos($p, '254') === 0) return $p;
    if (strlen($p) === 10 && $p[0] === '0') return '254' . substr($p, 1);
    return $p;
}

function initiate_stk_push(mysqli $conn, int $userId, string $phone, int $amount, string $accountRef = 'RoyalBridge'): array {
    $token = mpesa_access_token();

    $env = getenv('MPESA_ENV') ?: 'sandbox';
    $endpoint = $env === 'production'
      ? 'https://api.safaricom.co.ke/mpesa/stkpush/v1/processrequest'
      : 'https://sandbox.safaricom.co.ke/mpesa/stkpush/v1/processrequest';

    $shortCode   = getenv('MPESA_SHORTCODE');
    $passkey     = getenv('MPESA_PASSKEY');
    $timestamp   = date('YmdHis');
    $password    = base64_encode($shortCode . $passkey . $timestamp);
    $callbackUrl = getenv('MPESA_CALLBACK_URL');

    $payload = [
      'BusinessShortCode' => $shortCode,
      'Password'          => $password,
      'Timestamp'         => $timestamp,
      'TransactionType'   => 'CustomerPayBillOnline',
      'Amount'            => $amount,
      'PartyA'            => normalize_msisdn($phone),
      'PartyB'            => $shortCode,
      'PhoneNumber'       => normalize_msisdn($phone),
      'CallBackURL'       => $callbackUrl,
      'AccountReference'  => $accountRef,
      'TransactionDesc'   => 'Deposit to RoyalBridge'
    ];

    $ch = curl_init($endpoint);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
      'Content-Type: application/json',
      'Authorization: Bearer ' . $token
    ]);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    if (curl_errno($ch)) { throw new Exception('STK push error: ' . curl_error($ch)); }
    curl_close($ch);

    $data = json_decode($response, true) ?: [];

    // Track request
    $mrid = $data['MerchantRequestID'] ?? null;
    $crid = $data['CheckoutRequestID'] ?? null;
    $stmt = $conn->prepare(
      "INSERT INTO mpesa_requests (user_id, phone, amount, merchant_request_id, checkout_request_id, status)
       VALUES (?, ?, ?, ?, ?, 'PENDING')"
    );
    $stmt->bind_param("isiss", $userId, $phone, $amount, $mrid, $crid);
    $stmt->execute();

    return $data;
}