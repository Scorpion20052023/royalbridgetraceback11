<?php
require_once __DIR__ . '/../connect.php';

function handle_mpesa_callback(mysqli $conn) {
  $raw = file_get_contents('php://input');
  file_put_contents(__DIR__ . '/../../logs/mpesa_callback_raw.log', date('c') . ' ' . $raw . PHP_EOL, FILE_APPEND);

  $json = json_decode($raw, true);
  $stk  = $json['Body']['stkCallback'] ?? null;
  if (!$stk) { http_response_code(400); echo 'No stkCallback'; return; }

  $merchantReqId = $stk['MerchantRequestID'] ?? '';
  $checkoutReqId = $stk['CheckoutRequestID'] ?? '';
  $resultCode    = $stk['ResultCode'] ?? -1;
  $resultDesc    = $stk['ResultDesc'] ?? '';

  // Update request status
  $status = ($resultCode === 0) ? 'SUCCESS' : 'FAILED';
  $stmt = $conn->prepare("UPDATE mpesa_requests SET status=?, result_desc=? WHERE merchant_request_id=? AND checkout_request_id=?");
  if ($stmt) {
    $stmt->bind_param("ssss", $status, $resultDesc, $merchantReqId, $checkoutReqId);
    if (!$stmt->execute()) {
      file_put_contents(__DIR__ . '/../../logs/errors.log', date('c') . ' UPDATE_ERROR ' . $stmt->error . PHP_EOL, FILE_APPEND);
    }
    $stmt->close();
  }

  if ($resultCode === 0) {
    // Extract metadata
    $meta = $stk['CallbackMetadata']['Item'] ?? [];
    $amount = 0; $receipt = ''; $phone = '';
    foreach ($meta as $item) {
      if ($item['Name'] === 'Amount') $amount = (float)$item['Value'];
      if ($item['Name'] === 'MpesaReceiptNumber') $receipt = $item['Value'];
      if ($item['Name'] === 'PhoneNumber') $phone = $item['Value'];
    }

    // Find user by request
    $qry = $conn->prepare("SELECT user_id FROM mpesa_requests WHERE checkout_request_id=? LIMIT 1");
    $qry->bind_param("s", $checkoutReqId);
    $qry->execute();
    $res = $qry->get_result();

    if ($row = $res->fetch_assoc()) {
      $userId = (int)$row['user_id'];

      // Idempotency: avoid double-credit by receipt
      $check = $conn->prepare("SELECT id FROM transactions WHERE mpesa_ref=? LIMIT 1");
      $check->bind_param("s", $receipt);
      $check->execute();
      if (!$check->get_result()->fetch_assoc()) {
        $conn->begin_transaction();
        try {
          // Insert transaction
          $stmt1 = $conn->prepare("
            INSERT INTO transactions (user_id, category, amount, method, status, mpesa_ref)
            VALUES (?, 'deposit', ?, 'mpesa', 'success', ?)
          ");
          $stmt1->bind_param("ids", $userId, $amount, $receipt);
          $stmt1->execute();
          if ($stmt1->error) throw new Exception($stmt1->error);
          $stmt1->close();

          // Ensure wallet row exists
          $conn->query("INSERT IGNORE INTO wallets (user_id) VALUES ($userId)");

          // Update wallet deposit balance
          $stmt2 = $conn->prepare("UPDATE wallets SET deposit_balance = deposit_balance + ? WHERE user_id=?");
          $stmt2->bind_param("di", $amount, $userId);
          $stmt2->execute();
          if ($stmt2->error) throw new Exception($stmt2->error);
          $stmt2->close();

          $conn->commit();

          // Debug log
          file_put_contents(__DIR__ . '/../../logs/debug.log',
            date('c') . " CREDIT_OK user=$userId deposit=$amount receipt=$receipt" . PHP_EOL,
            FILE_APPEND
          );
        } catch (Throwable $e) {
          $conn->rollback();
          file_put_contents(__DIR__ . '/../../logs/errors.log',
            date('c') . ' WALLET_CREDIT_ERROR ' . $e->getMessage() . PHP_EOL,
            FILE_APPEND
          );
        }
      }
      $check->close();
    }
    $qry->close();
  }

  header('Content-Type: application/json');
  echo json_encode(['ResultCode' => 0, 'ResultDesc' => 'Callback received']);
}