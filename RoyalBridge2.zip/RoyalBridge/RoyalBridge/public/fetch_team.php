<?php
session_start();
require_once __DIR__ . '/backend/connect.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Not logged in']);
    exit;
}

$userId = $_SESSION['user_id'];

// Fetch team members (users where referrer_id = current user)
// Join wallets to get total_deposits
$sql = "
    SELECT 
        u.username, 
        u.email,
        u.phone, 
        u.package, 
        COALESCE(w.total_deposits, 0.00) as total_deposits
    FROM users u
    LEFT JOIN wallets w ON u.id = w.user_id
    WHERE u.referrer_id = ?
    ORDER BY u.created_at DESC
";

$stmt = $conn->prepare($sql);
if (!$stmt) {
    echo json_encode(['status' => 'error', 'message' => 'Query preparation failed']);
    exit;
}

$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();

$team = [];
$rank = 1;

while ($row = $result->fetch_assoc()) {
    $team[] = [
        'rank' => $rank++,
        'name' => $row['username'],
        'email' => $row['email'],
        'phone' => $row['phone'],
        'deposit' => number_format($row['total_deposits'], 2) . ' KES',
        'membership' => $row['package']
    ];
}

echo json_encode(['status' => 'success', 'data' => $team]);
?>
