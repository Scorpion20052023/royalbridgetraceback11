<?php
require_once __DIR__ . '/../backend/connect.php';

echo "<h2>Time Debug</h2>";
echo "PHP Time: " . date("Y-m-d H:i:s") . "<br>";
$res = $conn->query("SELECT NOW() as db_time");
$row = $res->fetch_assoc();
echo "DB Time:  " . $row['db_time'] . "<br>";

echo "<h2>Password Resets Table</h2>";
$res = $conn->query("SELECT * FROM password_resets ORDER BY id DESC LIMIT 5");
if ($res->num_rows > 0) {
    echo "<table border='1'><tr><th>ID</th><th>Email</th><th>Token</th><th>Expires At</th><th>Created At</th></tr>";
    while($row = $res->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . $row['email'] . "</td>";
        echo "<td>" . substr($row['token'], 0, 10) . "...</td>";
        echo "<td>" . $row['expires_at'] . "</td>";
        echo "<td>" . $row['created_at'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "No records found.";
}

if (isset($_GET['token']) && isset($_GET['email'])) {
    echo "<h2>Current Request Check</h2>";
    $email = $_GET['email'];
    $token = $_GET['token'];
    
    echo "Checking Email: " . htmlspecialchars($email) . "<br>";
    echo "Checking Token: " . htmlspecialchars($token) . "<br>";
    
    $stmt = $conn->prepare("SELECT * FROM password_resets WHERE email=? AND token=?");
    $stmt->bind_param("ss", $email, $token);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        echo "Record Found!<br>";
        echo "Expires At: " . $row['expires_at'] . "<br>";
        echo "Valid? " . (strtotime($row['expires_at']) > time() ? "Yes (PHP check)" : "No (PHP check)") . "<br>";
    } else {
        echo "No matching record for this email/token pair.<br>";
    }
}
?>
