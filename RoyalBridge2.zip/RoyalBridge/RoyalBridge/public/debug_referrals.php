require_once __DIR__ . '/../backend/connect.php';

echo "<h1>Debug Referral Data (Global)</h1>";

// 1. Check if ANYONE has a referrer_id
$sql = "SELECT id, username, email, phone, referrer_id, created_at FROM users WHERE referrer_id IS NOT NULL";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<h2>Found {$result->num_rows} referred users in Total:</h2>";
    echo "<table border='1'><tr><th>ID</th><th>Username</th><th>Email</th><th>Phone</th><th>Referrer ID</th><th>Date</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>{$row['id']}</td>";
        echo "<td>{$row['username']}</td>";
        echo "<td>{$row['email']}</td>";
        echo "<td>{$row['phone']}</td>";
        echo "<td>{$row['referrer_id']}</td>";
        echo "<td>{$row['created_at']}</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<h2>No referred users found in the entire database.</h2>";
    echo "This confirms that NO ONE has been linked correctly yet.";
}

if ($result->num_rows > 0) {
    echo "<h2>Found {$result->num_rows} referred users:</h2>";
    echo "<table border='1'><tr><th>ID</th><th>Username</th><th>Referrer ID</th><th>Date</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>{$row['id']}</td>";
        echo "<td>{$row['username']}</td>";
        echo "<td>{$row['referrer_id']}</td>";
        echo "<td>{$row['created_at']}</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<h2>No referred users found.</h2>";
    echo "This means no user in the `users` table has `referrer_id = $currentUserId`.";
}

// 2. Output raw fetch_team.php logic
echo "<hr><h2>Simulating fetch_team.php:</h2>";
$sql2 = "
    SELECT 
        u.username, 
        u.phone, 
        u.package, 
        COALESCE(w.total_deposits, 0.00) as total_deposits
    FROM users u
    LEFT JOIN wallets w ON u.id = w.user_id
    WHERE u.referrer_id = ?
    ORDER BY u.created_at DESC
";
$stmt2 = $conn->prepare($sql2);
$stmt2->bind_param("i", $currentUserId);
$stmt2->execute();
$res2 = $stmt2->get_result();

$data = [];
while ($r = $res2->fetch_assoc()) {
    $data[] = $r;
}
echo "<pre>" . json_encode($data, JSON_PRETTY_PRINT) . "</pre>";
?>
