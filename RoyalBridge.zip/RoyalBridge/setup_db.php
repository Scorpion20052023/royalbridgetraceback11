<?php
require_once __DIR__ . '/backend/connect.php';

$sql = "CREATE TABLE IF NOT EXISTS password_resets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL,
    token VARCHAR(255) NOT NULL,
    expires_at DATETIME NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX (email)
)";

if ($conn->query($sql) === TRUE) {
    echo "Table 'password_resets' checked/created successfully.<br>";
} else {
    echo "Error creating table: " . $conn->error . "<br>";
}

// Create referrals table
$sqlRef = "CREATE TABLE IF NOT EXISTS referrals (
    id INT AUTO_INCREMENT PRIMARY KEY,
    referrer_id INT NOT NULL,
    referred_user_id INT NOT NULL,
    status ENUM('pending', 'paid') NOT NULL DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (referrer_id) REFERENCES users(id),
    FOREIGN KEY (referred_user_id) REFERENCES users(id)
)";

if ($conn->query($sqlRef) === TRUE) {
    echo "Table 'referrals' checked/created successfully.<br>";
    
    // Backfill logic: Insert missing referrals from users table
    $backfill = "INSERT INTO referrals (referrer_id, referred_user_id, status, created_at)
                 SELECT u.referrer_id, u.id, 'pending', u.created_at
                 FROM users u
                 LEFT JOIN referrals r ON u.id = r.referred_user_id
                 WHERE u.referrer_id IS NOT NULL AND r.id IS NULL";
                 
    if ($conn->query($backfill) === TRUE) {
        if ($conn->affected_rows > 0) {
            echo "Backfilled " . $conn->affected_rows . " existing referrals.<br>";
        } else {
            echo "Referrals table is up to date.<br>";
        }
    } else {
        echo "Error backfilling referrals: " . $conn->error . "<br>";
    }
} else {
    echo "Error creating referrals table: " . $conn->error . "<br>";
}
?>
