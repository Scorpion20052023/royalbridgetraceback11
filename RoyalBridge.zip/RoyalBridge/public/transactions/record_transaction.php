<?php
require_once __DIR__ . '/../../backend/connect.php';

/**
 * Record a transaction and update wallet balances.
 *
 * @param mysqli $conn
 * @param int    $userId
 * @param string $category   e.g. 'investment_principal', 'investment_return', 'affiliate', 'cashback', 'withdrawal'
 * @param float  $amount
 * @param string $method     default 'system'
 * @param string $status     e.g. 'confirmed', 'matured', 'success'
 * @param string $ref        e.g. '5-day' for investments
 * @param int    $views
 */
function record_transaction($conn, $userId, $category, $amount, $method='system', $status='success', $ref=null, $views=0) {
    // Map internal logic categories to 'investment' for DB storage if needed
    $dbCategory = $category;
    if ($category === 'investment_principal' || $category === 'investment_return') {
        $dbCategory = 'investment';
    }

    $stmt = $conn->prepare("
        INSERT INTO transactions (user_id, category, amount, views, method, status, mpesa_ref, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
    ");
    $stmt->bind_param("isdisss", $userId, $dbCategory, $amount, $views, $method, $status, $ref);
    $stmt->execute();
    $stmt->close();

    // Update wallet depending on category
    switch ($category) {
        case 'affiliate':
            $conn->query("UPDATE wallets SET affiliate_balance = affiliate_balance + $amount WHERE user_id=$userId");
            break;
        case 'cashback':
            $conn->query("UPDATE wallets SET cashback_balance = cashback_balance + $amount WHERE user_id=$userId");
            break;
        case 'investment_principal':
            // Deduct principal from deposit_balance, increase invested_capital
            $conn->query("UPDATE wallets 
                          SET deposit_balance = deposit_balance - $amount
                          WHERE user_id=$userId");
            break;
        case 'investment_return':
            // Credit profit back to account_balance
            $conn->query("UPDATE wallets 
                          SET account_balance = account_balance + $amount
                          WHERE user_id=$userId");
            break;
        case 'withdrawal':
            $conn->query("UPDATE wallets SET total_withdrawn = total_withdrawn + $amount WHERE user_id=$userId");
            break;
    }

    file_put_contents(__DIR__ . '/../../logs/debug.log',
        date('c') . " TX_OK user=$userId category=$category amount=$amount views=$views ref=$ref" . PHP_EOL,
        FILE_APPEND
    );
}
