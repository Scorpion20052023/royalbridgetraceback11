<?php
require_once __DIR__ . '/../../backend/connect.php';
session_start();
$userId = $_SESSION['user_id'] ?? 0;

// Query all transactions for this user, include views
$sql = "SELECT category, amount, views, method, status, mpesa_ref, created_at
        FROM transactions WHERE user_id=? AND category != 'token_purchase' ORDER BY created_at DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$res = $stmt->get_result();

// Initialize all categories so frontend always has keys
$data = [
    'deposit'    => [],
    'investment' => [],
    'cashback'   => [],
    'withdrawal' => [],
    'aviator'    => [],
    'forex'      => [],
    'affiliate'  => [],
    'whatsapp'   => [],
    'service_purchase' => []
];

// Map DB category values to frontend keys
$map = [
    'deposit'    => 'deposit',
    'investment' => 'investment',
    'cashback'   => 'cashback',
    'withdrawal' => 'withdrawal',
    'aviator'    => 'aviator',
    'forex'      => 'forex',
    'affiliate'  => 'affiliate',
    'whatsapp'   => 'whatsapp',
    'service_purchase' => 'service_purchase',
    'investment_principal' => 'investment',
    'investment_return'    => 'investment'
];

while ($row = $res->fetch_assoc()) {
    $cat = strtolower($row['category']);
    if (isset($map[$cat])) {
        // Cast views to int so frontend gets a number
        $row['views'] = isset($row['views']) ? (int)$row['views'] : 0;
        $data[$map[$cat]][] = $row;
    } else {
        file_put_contents(__DIR__ . '/../../logs/errors.log',
            date('c') . " UNKNOWN_CATEGORY {$row['category']} for user=$userId" . PHP_EOL,
            FILE_APPEND
        );
    }
}

header('Content-Type: application/json');
echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
