<?php
require_once __DIR__ . "/../backend/connect.php";

$res = $conn->query("
    SELECT file_name 
    FROM daily_uploads 
    ORDER BY id DESC 
    LIMIT 1
");

if ($res && $res->num_rows > 0) {
    $file = $res->fetch_assoc()['file_name'];
    echo json_encode([
        "status" => "success",
        "image" => "uploads/daily_products/" . $file
    ]);
} else {
    echo json_encode(["status" => "empty"]);
}
