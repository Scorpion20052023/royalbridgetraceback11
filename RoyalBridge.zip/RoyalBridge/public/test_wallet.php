<?php
// test_wallet.php

require_once __DIR__ . '/../backend/connect.php'; // adjust path to your DB connection

// Change this to the user_id you want to test
$userId = 7;

$stmt = $conn->prepare("
    SELECT 
        user_id,
        deposit_balance,
        total_deposits,
        account_balance,
        account_total,
        total_withdrawn,
        affiliate_balance,
        affiliate_withdrawn,
        cashback_balance,
        cashback_withdrawn,
        whatsapp_balance,
        whatsapp_withdrawn,
        invested_capital
    FROM wallets
    WHERE user_id = ?
    LIMIT 1
");
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

if ($row) {
    echo "<h2>Wallet Test for User ID {$row['user_id']}</h2>";
    echo "<ul>";
    echo "<li>Deposit Balance: KES " . number_format($row['deposit_balance'], 2) . "</li>";
    echo "<li>Total Deposits: KES " . number_format($row['total_deposits'], 2) . "</li>";
    echo "<li>Account Balance: KES " . number_format($row['account_balance'], 2) . "</li>";
    echo "<li>Account Total: KES " . number_format($row['account_total'], 2) . "</li>";
    echo "<li>Total Withdrawn: KES " . number_format($row['total_withdrawn'], 2) . "</li>";
    echo "<li>Affiliate Balance: KES " . number_format($row['affiliate_balance'], 2) . "</li>";
    echo "<li>Affiliate Withdrawn: KES " . number_format($row['affiliate_withdrawn'], 2) . "</li>";
    echo "<li>Cashback Balance: KES " . number_format($row['cashback_balance'], 2) . "</li>";
    echo "<li>Cashback Withdrawn: KES " . number_format($row['cashback_withdrawn'], 2) . "</li>";
    echo "<li>Whatsapp Balance: KES " . number_format($row['whatsapp_balance'], 2) . "</li>";
    echo "<li>Whatsapp Withdrawn: KES " . number_format($row['whatsapp_withdrawn'], 2) . "</li>";
    echo "<li>Invested Capital: KES " . number_format($row['invested_capital'], 2) . "</li>";
    echo "</ul>";
} else {
    echo "No wallet record found for user ID {$userId}.";
}
?>
