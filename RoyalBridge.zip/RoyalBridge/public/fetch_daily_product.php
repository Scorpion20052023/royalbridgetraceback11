<?php
ob_start();
require_once __DIR__ . "/../backend/connect.php"; // Fixed path relative to public/

try {
    $res = $conn->query("SELECT file_name FROM daily_uploads ORDER BY id DESC LIMIT 1");

    if ($row = $res->fetch_assoc()) {
        $data = [
            "status" => "success",
            "image_url" => "uploads/daily_products/" . $row["file_name"]
        ];
    } else {
        $data = ["status" => "empty"];
    }

    ob_end_clean();
    echo json_encode($data);

} catch (Throwable $e) {
    ob_end_clean();
    echo json_encode(["status" => "error", "message" => $e->getMessage()]);
}
?>
