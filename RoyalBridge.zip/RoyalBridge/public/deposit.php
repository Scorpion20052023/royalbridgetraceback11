<?php
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: index.php'); exit; }

require_once __DIR__ . '/../backend/connect.php';
require_once __DIR__ . '/../backend/payhero/stkpush.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $amount = (int)($_POST['amount'] ?? 0);
    $phone  = trim($_POST['phone'] ?? '');

    if ($amount < 1) { http_response_code(400); echo 'Invalid amount'; exit; }
    if (!$phone) { http_response_code(400); echo 'Phone required'; exit; }

    try {
        $res = initiate_payhero_stk_push($conn, $_SESSION['user_id'], $phone, $amount);
        header('Content-Type: application/json');
        echo json_encode(['ok' => true, 'data' => $res]);
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
    }
}