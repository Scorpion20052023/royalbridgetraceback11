<?php
session_start();
require_once __DIR__ . '/../backend/connect.php';

$showLogin = false;
if (isset($_GET['login'])) {
    $showLogin = true;
}

// Capture Referral Code
if (isset($_GET['ref'])) {
    $_SESSION['referrer_code'] = trim($_GET['ref']);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Home</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="css/styles.css" rel="stylesheet">
    <link href="css/popup.css" rel="stylesheet"> <!-- popup styles -->
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>@import url('https://fonts.googleapis.com/css2?family=Dancing+Script:wght@400..700&display=swap');</style>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Chokokutai&display=swap" rel="stylesheet">
</head>
<body>
    <div class="wrapper <?php echo $showLogin ? '' : ''; ?>">
        <span class="bg-animate"></span>
        <span class="bg-animate2"></span>

        <!-- Login form -->
        <div class="form-box login">
            <h2 class="animation" style="--i:0; --j:29;">Log In</h2>
            <form action="login.php" method="POST" autocomplete="off">
                <div class="input-box animation" style="--i:1; --j:30;">
                    <input type="text" name="username" id="login-username" required>
                    <label for="login-username">Username</label>
                    <i class='bx bxs-user'></i>
                </div>

                <div class="input-box animation" style="--i:2; --j:31;">
                    <input type="password" name="password" id="login-password" required>
                    <label for="login-password">Password</label>
                    <i class='bx bxs-show toggle-password' data-target="login-password" style="cursor: pointer;"></i>
                </div>

                <div id="logRole" class="logRole animation" style="--i:3; --j:32;">
                    <div class="input-row">
                        <label class="role-label">Log In As:</label>
                        <select name="role" class="role-select" required>
                            <option value="user">User</option>
                            <option value="admin">Admin</option>
                        </select>
                    </div> 
                </div>

                <button type="submit" class="btn animation" value="Login" name="login" style="--i:4; --j:33;">Login</button>

                <div class="logreg-link animation" style="--i:5; --j:34;">
                    <p>Don't have an account? <a href="#" class="register-link">Sign Up</a></p>
                </div>
                <p class="logreg-link animation recover" style="--i:5; --j:34;"><a href="#" id="forgotLink">Forgot password?</a></p>
            </form>
        </div>
        
        <div class="info-text login">
            <h2 class="animation" style="--i:0; --j:29;">Welcome Back!</h2>
            <p class="animation" style="--i:1; --j:30;">Invest today — let your money write its own story.</p>
        </div>

        <!-- Register form -->
        <div class="form-box register">
            <h2 class="animation" style="--i:23; --j:0;">Sign Up</h2>
            <form method="post" action="register.php" autocomplete="off">
                <div class="input-box animation" style="--i:24; --j:1;" >
                    <input type="text" name="username" id="register-username" required autocomplete="username">
                    <label for="register-username">Username</label>
                    <i class='bx bxs-user'></i>
                </div>

                <div class="input-box animation" style="--i:25; --j:2;">
                    <input type="email" name="email" id="register-email" required autocomplete="email">
                    <label for="register-email">E-mail</label>
                    <i class='bx bxs-envelope'></i>
                </div>

                <div class="input-box animation" style="--i:26; --j:3;">
                    <input type="tel" name="phone" id="register-phone" required pattern="[0-9+]{7,20}" autocomplete="tel">
                    <label for="register-phone">Phone Number</label>
                    <i class='bx bxs-phone'></i>
                </div>

                <div class="input-box animation" style="--i:27; --j:4;">
                    <input type="password" name="password" id="register-password" required autocomplete="new-password">
                    <label for="register-password">Password</label>
                    <i class='bx bxs-show toggle-password' data-target="register-password" style="cursor: pointer;"></i>
                </div>

                <button type="submit" class="btn animation" value="Sign Up" name="signup" style="--i:28; --j:5;">Sign Up</button>

                <div class="logreg-link animation" style="--i:29; --j:6;">
                    <p>Already have an account? <a href="#" class="login-link">Login</a></p>
                </div>
            </form>
        </div>

        <div class="info-text register">
            <h2 class="animation" style="--i:24; --j:0;">Welcome!</h2>
            <p class="animation" style="--i:25; --j:1;">From your hand to your future: wealth begins here.</p>
        </div>
    </div>

    <!-- Popup container -->
    <div id="popup" class="popup"></div>

    <!-- External JS -->
    <script src="./js/popup.js"></script>
    <script src="./js/script.js"></script>

    <!-- Trigger popups from PHP session messages -->
    <?php if (isset($_SESSION['reg_success'])): ?>
      <script>showPopup("<?php echo $_SESSION['reg_success']; ?>", "success");</script>
      <?php unset($_SESSION['reg_success']); ?>
    <?php endif; ?>

    <?php if (isset($_SESSION['reg_error'])): ?>
      <script>showPopup("<?php echo $_SESSION['reg_error']; ?>", "error");</script>
      <?php unset($_SESSION['reg_error']); ?>
    <?php endif; ?>

    <?php if (isset($_SESSION['login_error'])): ?>
      <script>showPopup("<?php echo $_SESSION['login_error']; ?>", "error");</script>
      <?php unset($_SESSION['login_error']); ?>
    <?php endif; ?>

    <?php if (isset($_SESSION['login_success'])): ?>
      <script>showPopup("<?php echo $_SESSION['login_success']; ?>", "success");</script>
      <?php unset($_SESSION['login_success']); ?>
    <?php endif; ?>
    <!-- Forgot Password Popup -->
    <div id="forgotPopup" class="forgot-popup">
        <div class="forgot-content">
            <span class="close-forgot">&times;</span>
            <h2>Reset Password</h2>
            <p>Enter your email to receive a reset link.</p>
            <form id="forgotForm">
                <input type="email" name="email" required placeholder="Enter your email address">
                <button type="submit">Send Reset Link</button>
            </form>
            <div id="forgotMsg" style="margin-top: 15px; min-height: 20px;"></div>
        </div>
    </div>

    <!-- Forgot Password JS -->
    <script>
        const forgotLink = document.getElementById('forgotLink');
        const forgotPopup = document.getElementById('forgotPopup');
        const closeForgot = document.querySelector('.close-forgot');
        const forgotForm = document.getElementById('forgotForm');
        const forgotMsg = document.getElementById('forgotMsg');

        if(forgotLink) {
            forgotLink.onclick = (e) => {
                e.preventDefault();
                forgotPopup.style.display = 'flex';
            };
        }
        
        if(closeForgot) {
            closeForgot.onclick = () => {
                forgotPopup.style.display = 'none';
                forgotMsg.innerText = '';
            };
        }

        window.onclick = (e) => {
            if (e.target == forgotPopup) {
                forgotPopup.style.display = 'none';
                forgotMsg.innerText = '';
            }
        };

        if(forgotForm) {
            forgotForm.onsubmit = (e) => {
                e.preventDefault();
                const btn = forgotForm.querySelector('button');
                const email = forgotForm.querySelector('input').value;
                
                btn.disabled = true;
                btn.innerText = 'Sending...';
                forgotMsg.style.color = '#fff';
                forgotMsg.innerText = '';

                const formData = new FormData();
                formData.append('email', email);

                fetch('send_reset_link.php', {
                    method: 'POST',
                    body: formData
                })
                .then(res => res.json())
                .then(data => {
                    btn.disabled = false;
                    btn.innerText = 'Send Reset Link';
                    
                    if(data.ok) {
                        forgotMsg.style.color = '#00ff08'; // Green
                        forgotMsg.innerText = data.message;
                        // Optional: close after delay
                        // setTimeout(() => forgotPopup.style.display = 'none', 3000);
                    } else {
                        forgotMsg.style.color = '#ff493c'; // Red
                        forgotMsg.innerText = data.error;
                    }
                })
                .catch(err => {
                    btn.disabled = false;
                    btn.innerText = 'Send Reset Link';
                    forgotMsg.style.color = '#ff493c';
                    forgotMsg.innerText = 'Connection Error';
                });
            };
        }
    </script>
</body>
</html>