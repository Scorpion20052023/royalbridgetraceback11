<?php
session_start();
require_once __DIR__ . "/../backend/connect.php";
require_once __DIR__ . "/transactions/record_transaction.php"; // Helper to record transaction

header("Content-Type: application/json");

// 1. Auth Check
if (!isset($_SESSION['user_id'])) {
    echo json_encode(["status" => "error", "message" => "Not authenticated"]);
    exit;
}
$user_id = $_SESSION['user_id'];

// 2. Input Validation
$package_name = $_POST['package_name'] ?? '';
$amount = floatval($_POST['amount'] ?? 0);

if (empty($package_name) || $amount <= 0) {
    echo json_encode(["status" => "error", "message" => "Invalid package details"]);
    exit;
}

// 3. Fetch User Wallet for Balance Check
$stmt = $conn->prepare("SELECT deposit_balance FROM wallets WHERE user_id = ? LIMIT 1");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$res = $stmt->get_result();
$wallet = $res->fetch_assoc();
$stmt->close();

if (!$wallet) {
    echo json_encode(["status" => "error", "message" => "Wallet not found"]);
    exit;
}

// Admin Bypass
$isAdmin = isset($_SESSION['admin_id']);

if (!$isAdmin && $wallet['deposit_balance'] < $amount) {
    echo json_encode(["status" => "error", "message" => "Insufficient funds in Deposit Wallet"]);
    exit;
}

// 4. Check for Package Downgrade
// Fetch current user package
$stmtUser = $conn->prepare("SELECT package FROM users WHERE id = ? LIMIT 1");
$stmtUser->bind_param("i", $user_id);
$stmtUser->execute();
$resUser = $stmtUser->get_result();
$currUser = $resUser->fetch_assoc();
$current_package = $currUser['package'] ?? '';
$stmtUser->close();

$package_ranks = [
    'Elite Membership'    => 1,
    'Prestige Membership' => 2,
    'Deluxe Membership'   => 3,
    'Grand Membership'    => 4
];

$current_rank = $package_ranks[$current_package] ?? 0;
$new_rank     = $package_ranks[$package_name] ?? 0;

// Only enforce if both are recognized membership packages
if ($current_rank > 0 && $new_rank > 0 && $new_rank < $current_rank) {
    echo json_encode(["status" => "error", "message" => "You cannot downgrade your service package."]);
    exit;
}

// 4. Process Transaction (Atomic)
$conn->begin_transaction();

try {
    // A. Deduct from Wallet (Deposit Balance) - ONLY IF NOT ADMIN
    if (!$isAdmin) {
        $new_balance = $wallet['deposit_balance'] - $amount;
        $updateW = $conn->prepare("UPDATE wallets SET deposit_balance = ? WHERE user_id = ?");
        $updateW->bind_param("di", $new_balance, $user_id);
        if (!$updateW->execute()) throw new Exception("Failed to deduct funds");
        $updateW->close();
    }

    // B. Update User Package
    $updateUser = $conn->prepare("UPDATE users SET package = ? WHERE id = ?");
    $updateUser->bind_param("si", $package_name, $user_id);
    if (!$updateUser->execute()) throw new Exception("Failed to update user package");
    $updateUser->close();

    // C. Record Transaction using helper (category: purchase/withdrawal-like)
    // We'll use a custom category or 'withdrawal' logic if strict categories exist, 
    // but 'service_purchase' would be best. record_transaction function might need update if category is strict.
    // Based on `record_transaction.php`, allowed categories are: 'investment_principal', 'investment_return', 'affiliate', 'cashback', 'withdrawal'.
    // None fit perfectly. Let's treat it as a special transaction in the transactions table directly to avoid messing up specific wallet logic in the helper, 
    // OR just log it manually here since we already did the deduction manually in step A.
    
    // Let's manually insert to `transactions` to avoid side-effects of `record_transaction` helper which updates wallets again.
    $stmtTx = $conn->prepare("INSERT INTO transactions (user_id, category, amount, method, status, mpesa_ref, description, created_at) VALUES (?, 'service_purchase', ?, 'system', 'success', ?, ?, NOW())");
    $ref = $package_name; 
    $desc = "Purchased package: " . $package_name;
    $stmtTx->bind_param("idss", $user_id, $amount, $ref, $desc);
    $stmtTx->execute();
    $stmtTx->close();

    // D. Award Cashback
    // "Buy Elite package @1,000.00 KES and get awarded 2,000.00 KES..."
    $cashback_rewards = [
        'Elite Membership'    => 2000,
        'Prestige Membership' => 5000,
        'Deluxe Membership'   => 7000,
        'Grand Membership'    => 10000
    ];

    if (isset($cashback_rewards[$package_name])) {
        $rewardArg = $cashback_rewards[$package_name];
        // record_transaction($conn, $userId, $category, $amount, $method='system', $status='success', $ref=null)
        // Category 'cashback' triggers update to cashback_balance in record_transaction helper
        record_transaction($conn, $user_id, 'cashback', $rewardArg, 'system', 'success', $package_name);
    }

    // E. Process Referral Commission (70%)
    // Fetch referrer
    $stmtRef = $conn->prepare("SELECT referrer_id, username FROM users WHERE id = ?");
    $stmtRef->bind_param("i", $user_id);
    $stmtRef->execute();
    $resRef = $stmtRef->get_result();
    $buyerData = $resRef->fetch_assoc();
    $stmtRef->close();

    if ($buyerData && !empty($buyerData['referrer_id'])) {
        $referrerId = $buyerData['referrer_id'];
        $buyerName = $buyerData['username'];
        $commission = $amount * 0.70;

        // Record for Referrer
        record_transaction($conn, $referrerId, 'affiliate', $commission, 'system', 'success', $buyerName);
    }

    $conn->commit();

    echo json_encode(["status" => "success", "message" => "Package purchased successfully"]);

} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(["status" => "error", "message" => $e->getMessage()]);
}
?>
