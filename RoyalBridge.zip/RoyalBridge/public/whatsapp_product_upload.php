<?php
ob_start(); // Start output buffering
session_start();

// Error handler to catch warnings as exceptions
set_error_handler(function($errno, $errstr, $errfile, $errline) {
    throw new ErrorException($errstr, 0, $errno, $errfile, $errline);
});

try {
    require_once __DIR__ . "/../backend/connect.php";

    if (!isset($_SESSION['admin_id'])) {
        // Fallback: Check if user is the admin user "Peter254"
        if (isset($_SESSION['username']) && $_SESSION['username'] === 'Peter254') {
            $_SESSION['admin_id'] = $_SESSION['user_id'];
        } else {
            throw new Exception("Unauthorized. keys: " . implode(",", array_keys($_SESSION)));
        }
    }

    if (!isset($_FILES['productImage'])) {
        throw new Exception("No file uploaded");
    }

    $uploadDir = __DIR__ . "/uploads/daily_products/";
    if (!is_dir($uploadDir)) {
        if (!mkdir($uploadDir, 0777, true)) {
            throw new Exception("Failed to create directory");
        }
    }

    // Fetch existing product
    $old = $conn->query("SELECT file_name FROM daily_uploads ORDER BY id DESC LIMIT 1");
    if ($old && $old->num_rows > 0) {
        $oldFile = $old->fetch_assoc()['file_name'];
        if (file_exists($uploadDir . $oldFile)) {
            @unlink($uploadDir . $oldFile);
        }
        $conn->query("DELETE FROM daily_uploads");
    }

    // Save new file
    $ext = pathinfo($_FILES['productImage']['name'], PATHINFO_EXTENSION);
    $newName = "daily_" . time() . "." . $ext;

    if (!move_uploaded_file($_FILES['productImage']['tmp_name'], $uploadDir . $newName)) {
         throw new Exception("Failed to move uploaded file");
    }

    // Insert record
    $stmt = $conn->prepare("INSERT INTO daily_uploads (file_name, uploaded_by) VALUES (?, ?)");
    $stmt->bind_param("si", $newName, $_SESSION['admin_id']);
    
    if (!$stmt->execute()) {
        throw new Exception("Database error: " . $stmt->error);
    }

    ob_end_clean(); // Discard any previous output/warnings
    
    if (isset($_POST['ajax'])) {
        echo json_encode([
            "status" => "success",
            "image_url" => "uploads/daily_products/" . $newName,
            "message" => "Product uploaded successfully"
        ]);
        exit;
    }

    header("Location: dashboard.php");
    exit;

} catch (Throwable $e) {
    ob_end_clean(); // Clean buffer
    if (isset($_POST['ajax'])) {
        echo json_encode([
            "status" => "error", 
            "message" => $e->getMessage()
        ]);
        exit;
    }
    die("Error: " . $e->getMessage());
}
?>
