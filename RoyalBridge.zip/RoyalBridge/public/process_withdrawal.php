<?php
session_start();
require_once __DIR__ . '/../backend/connect.php';
require_once __DIR__ . '/transactions/record_transaction.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit;
}

$user_id = $_SESSION['user_id'];
$amount  = floatval($_POST['amount'] ?? 0);
$wallet_type = $_POST['wallet_type'] ?? ''; // cashback, whatsapp, affiliates, etc.
$token_code  = $_POST['token'] ?? '';
$phone       = $_POST['phone'] ?? ''; // If used

if ($amount <= 0 || empty($wallet_type)) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid Request']);
    exit;
}

// Map Wallet to Column
$wallet_map = [
    'cashback'   => 'cashback_balance',
    'whatsapp'   => 'whatsapp_balance',
    'affiliates' => 'affiliate_balance',
    'invested'   => 'account_balance' // "Invested Earnings" -> account_balance usually
];

if (!isset($wallet_map[$wallet_type])) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid Wallet Type']);
    exit;
}

$column = $wallet_map[$wallet_type];

try {
    $conn->begin_transaction();

    // 1. Check Balance
    $stmt = $conn->prepare("SELECT $column FROM wallets WHERE user_id = ? FOR UPDATE");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $res = $stmt->get_result();
    $wData = $res->fetch_assoc();

    if (!$wData || $wData[$column] < $amount) {
        throw new Exception("Insufficient funds in $wallet_type wallet.");
    }

    // 2. Token Validation (Skip for Affiliate)
    if ($wallet_type !== 'affiliates') {
        if (empty($token_code)) {
            throw new Exception("Token code required for this withdrawal.");
        }

        // Fetch LATEST unused token matching code
        // "Every time a withdrawal is to be made, a new token is required and the latest one is the only one viable"
        // Implies: If I have 5 unused tokens, only the very last purchased one is valid? 
        // OR: Of the unused tokens, does the code provided match the latest one?
        // User said: "the latest one is the only one viable".
        // Let's enforce strictness: The user must provide the code of the *most recently purchased* token, AND it must be unused.
        
        $tStmt = $conn->prepare("SELECT id, token_type, token_code FROM withdrawal_tokens WHERE user_id = ? AND is_used = 0 ORDER BY created_at DESC LIMIT 1");
        $tStmt->bind_param("i", $user_id);
        $tStmt->execute();
        $tRes = $tStmt->get_result();
        $tokenData = $tRes->fetch_assoc();

        if (!$tokenData) {
            throw new Exception("No valid unused token found. Please buy one.");
        }

        // Check if Code Matches
        if ($tokenData['token_code'] !== $token_code) {
             throw new Exception("Invalid Token Code. Please use your latest purchased token.");
        }

        // Check Tier
        // Hierarchy: Verification(1) < Authorization(2) < Credentials(3) < Luxurious(4)
        $tiers = [
            'Verification Code' => 1,
            'Authorization Code' => 2,
            'Credentials Code'   => 3,
            'Luxurious Code'     => 4
        ];
        
        $tokenLevel = $tiers[$tokenData['token_type']] ?? 0;

        // Requirements
        // Whatsapp: Authorization (2)
        // Cashback: Credentials (3)
        // Others (Invested): Verification (1)
        
        $requiredLevel = 1; // Default
        if ($wallet_type === 'whatsapp') {
            $requiredLevel = 2; 
        } elseif ($wallet_type === 'cashback') {
            $requiredLevel = 3; 
        }

        if ($tokenLevel < $requiredLevel) {
            throw new Exception("Token too low tier. $wallet_type requires Level $requiredLevel (Yours: $tokenLevel)");
        }

        // Mark Used
        $upT = $conn->prepare("UPDATE withdrawal_tokens SET is_used=1 WHERE id=?");
        $upT->bind_param("i", $tokenData['id']);
        $upT->execute();
    }

    // 3. Deduct & Transact
    // Deduct
    $newBal = $wData[$column] - $amount;
    $upW = $conn->prepare("UPDATE wallets SET $column = ? WHERE user_id = ?");
    $upW->bind_param("di", $newBal, $user_id);
    $upW->execute();

    // Record 'withdrawal' transaction
    record_transaction($conn, $user_id, 'withdrawal', -$amount, 'system', 'success', "Withdraw from $wallet_type");

    $conn->commit();
    echo json_encode(['status' => 'success', 'message' => 'Withdrawal Successful! Funds sent.']);

} catch (Exception $e) {
    if ($conn->in_transaction) $conn->rollback();
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>
