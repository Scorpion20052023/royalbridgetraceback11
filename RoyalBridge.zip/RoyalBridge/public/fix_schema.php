<?php
require_once __DIR__ . "/../backend/connect.php";

echo "Attempting to fix schema...\n";

// 1. Alter Table
$sqlAttr = "ALTER TABLE transactions MODIFY COLUMN category ENUM('deposit','investment','whatsapp','cashback','aviator','forex','affiliate','withdrawal','service_purchase') NOT NULL";

if ($conn->query($sqlAttr) === TRUE) {
    echo "Schema updated successfully. Added 'service_purchase' to ENUM.\n";
} else {
    echo "Error updating schema: " . $conn->error . "\n";
}

// 2. Fix Broken Records
// We fix records where category is empty ('') and mpesa_ref indicates a package purchase
$sqlFix = "UPDATE transactions SET category='service_purchase' WHERE category='' AND (mpesa_ref LIKE '%Membership%' OR mpesa_ref = 'PKG_PURCHASE' OR description LIKE '%package%')";

if ($conn->query($sqlFix) === TRUE) {
    echo "Fixed/Recovered " . $conn->affected_rows . " broken transaction records.\n";
} else {
    echo "Error updating records: " . $conn->error . "\n";
}

$conn->close();
?>
