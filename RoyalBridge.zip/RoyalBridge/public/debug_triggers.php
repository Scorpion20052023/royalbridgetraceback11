<?php
require_once 'C:/xampp/htdocs/RoyalBridge/backend/connect.php';

$res = $conn->query("SHOW TRIGGERS LIKE 'wallets'");
if ($res) {
    echo "<h1>Triggers on 'wallets' table:</h1>";
    echo "<table border='1'><tr><th>Trigger</th><th>Event</th><th>Statement</th></tr>";
    while ($row = $res->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['Trigger'] . "</td>";
        echo "<td>" . $row['Event'] . "</td>";
        echo "<td><pre>" . htmlspecialchars($row['Statement']) . "</pre></td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "Error: " . $conn->error;
}
?>
