<?php
session_start();
require_once __DIR__ . '/../backend/connect.php';
require_once __DIR__ . '/transactions/record_transaction.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit;
}

$user_id = $_SESSION['user_id'];
$cost = 5000;

try {
    $conn->begin_transaction();

    // 1. Fetch User Package and Balance
    $stmt = $conn->prepare("SELECT package, deposit_balance FROM wallets w JOIN users u ON w.user_id = u.id WHERE u.id = ? FOR UPDATE");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $res = $stmt->get_result();
    $user = $res->fetch_assoc();

    if (!$user) {
        throw new Exception("User not found.");
    }

    $package = $user['package'];
    $balance = floatval($user['deposit_balance']);

    // 2. Check Package Constraint
    // Must be Deluxe or Grand
    if (strpos($package, 'Deluxe') === false && strpos($package, 'Grand') === false) {
        throw new Exception("Restricted: Requires Deluxe or Grand Membership.");
    }

    // 3. Check Balance
    $isAdmin = isset($_SESSION['admin_id']);
    
    if (!$isAdmin && $balance < $cost) {
        throw new Exception("Insufficient deposit balance. Required: KES " . number_format($cost));
    }

    // 4. Deduct Funds (Only if not admin)
    if (!$isAdmin) {
        $new_balance = $balance - $cost;
        $upStmt = $conn->prepare("UPDATE wallets SET deposit_balance = ? WHERE user_id = ?");
        $upStmt->bind_param("di", $new_balance, $user_id);
        if (!$upStmt->execute()) {
            throw new Exception("Failed to update balance.");
        }
    }

    // 5. Record Transaction
    // Category: forex
    record_transaction($conn, $user_id, 'forex', -$cost, 'system', 'success', 'Forex Signals Purchase');

    $conn->commit();
    echo json_encode(['status' => 'success', 'message' => 'Purchase Successful!']);

} catch (Exception $e) {
    if ($conn->in_transaction) {
        $conn->rollback();
    }
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>
