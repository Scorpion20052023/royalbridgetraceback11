//DASHBOARD SECTION

const navLinks = document.querySelectorAll('.nav-links a');
const sections = document.querySelectorAll('.section');

navLinks.forEach(link => {
  link.addEventListener("click", function (e) {
    e.preventDefault();

    const targetSection = this.getAttribute("data-section");

    // hide all sections
    sections.forEach(sec => sec.style.display = "none");

    // show selected section
    const activeSection = document.getElementById(targetSection);
    if (activeSection) {
      activeSection.style.display = "block";
    }

    // update nav highlight
    navLinks.forEach(nav => {
      nav.classList.remove("active");
      nav.setAttribute("aria-current", "false");
    });
    this.classList.add("active");
    this.setAttribute("aria-current", "true");

    // ==========================================
    // AVIATOR VIDEO AUTOPLAY — FULLY FIXED
    // ==========================================
    const aviatorVideo = document.getElementById("aviatorVideo");

    if (targetSection === "aviator") {
      // wait for DOM to render the visible section
      setTimeout(() => {
        if (aviatorVideo) {
          aviatorVideo.muted = true;        // autoplay requirement
          aviatorVideo.currentTime = 0;     // restart
          aviatorVideo.play().catch(err => {
            console.log("Autoplay blocked:", err);
          });
        }
      }, 60);
    } else {
      // pause when leaving aviator
      if (aviatorVideo) {
        aviatorVideo.pause();
        aviatorVideo.currentTime = 0;
      }
    }
  });
});


// Show the dashboard section by default
document.getElementById('dashie').style.display = 'block';

//Change color of active section-icon6
document.querySelectorAll('.nav-links .iconic').forEach(link => {
  link.addEventListener('click', (e) => {
    // clear previous
    document.querySelectorAll('.nav-links .iconic').forEach(l => {
      l.classList.remove('active');
      l.setAttribute('aria-current', 'false');
    });
    // set this one
    link.classList.add('active');
    link.setAttribute('aria-current', 'true');
  });
});


function updateDateTime() {
  const el = document.getElementById('currentDateTime');
  if (!el) return;
  const now = new Date();

  // human friendly text
  const human = now.toLocaleString(undefined, {
    weekday: 'short',    // "Mon"
    year: 'numeric',
    month: 'short',      // "Nov"
    day: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
    second: '2-digit',
    hour12: false        // set true for 12-hour clock
  });

  // machine-readable ISO datetime for the datetime attribute
  el.textContent = human;
  el.setAttribute('datetime', now.toISOString());
}

// initial render and start live updates (every second)
updateDateTime();
const dtTimer = setInterval(updateDateTime, 1000);

(function () {
  // IDs from your markup
  const dayTimeEl = document.getElementById('dayTime');
  const userNamEl = document.getElementById('userNam');

  // Optional: set a preferred timezone (IANA). Set to null to use user's local time.
  const TIMEZONE = 'Africa/Nairobi'; // or null

  // Optional: load user name from localStorage or other source; fallback to "Partner"
  const storedName = localStorage.getItem('userName'); // set earlier if you want persistence
  if (userNamEl) userNamEl.textContent = storedName || 'Partner';

  // Determine greeting from hour (0-23)
  function getGreeting(date) {
    const hr = date.getHours();
    if (hr >= 5 && hr < 12) return 'morning';
    if (hr >= 12 && hr < 17) return 'afternoon';
    if (hr >= 17 && hr < 21) return 'evening';
    return 'night';
  }

  // Get current day name
  function updateDayOfWeek() {
    const days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    const today = new Date();
    const dayName = days[today.getDay()];

    // Update span content
    document.getElementById("day-of-week").textContent = dayName;
  }

  // Run on page load
  window.onload = updateDayOfWeek;

  // Helper: get a Date object in the chosen timezone (if TIMEZONE is set)
  function nowInTimeZone(timeZone) {
    if (!timeZone) return new Date();
    // Create a locale string in the target TZ then parse into a Date
    const parts = new Date().toLocaleString('en-US', { timeZone }).replace(',', '');
    return new Date(parts);
  }

  // Update the greeting text
  function updateGreeting() {
    const now = TIMEZONE ? nowInTimeZone(TIMEZONE) : new Date();
    const greeting = getGreeting(now);
    if (dayTimeEl) dayTimeEl.textContent = greeting;
  }

  // Set initial value
  updateGreeting();

  // Recompute at the start of each minute to catch boundary changes
  const msToNextMinute = (60 - new Date().getSeconds()) * 1000 + 50;
  setTimeout(function () {
    updateGreeting();
    setInterval(updateGreeting, 60 * 1000);
  }, msToNextMinute);
})();

// Handle "Upgrade Now" button navigation
document.getElementById('upPkg').addEventListener('click', function (e) {
  e.preventDefault();

  // Target section ID
  const target = this.getAttribute('data-section');
  if (!target) return;

  // Hide all other sections
  document.querySelectorAll('.section').forEach(sec => {
    sec.style.display = 'none';
  });

  // Show the service package section
  document.getElementById(target).style.display = 'block';

  // Optional: highlight the matching sidebar link
  document.querySelectorAll('.nav-links .iconic').forEach(link => {
    link.classList.remove('active');
    link.setAttribute('aria-current', 'false');
  });
  const match = document.querySelector(`.nav-links a[data-section="${target}"]`);
  if (match) {
    match.classList.add('active');
    match.setAttribute('aria-current', 'true');
  }

  // Smooth scroll to top (optional UX touch)
  window.scrollTo({ top: 0, behavior: 'smooth' });
});


//DEPOSIT SECTION

document.getElementById('depoForm').addEventListener('submit', function (e) {
  const phone = document.getElementById('phoneNo').value;
  if (!/^\d{10}$/.test(phone)) {
    e.preventDefault();
    alert('Please enter a valid 10-digit phone number.');
  }
});


//CAPITAL SECTION

document.getElementById('duration').addEventListener('change', calculateProfit);
document.getElementById('amount').addEventListener('input', calculateProfit);

function calculateProfit() {
  const amount = parseFloat(document.getElementById('amount').value) || 0;
  const days = parseInt(document.getElementById('duration').value, 10);
  let rate = 1.3; // default rate

  switch (days) {
    case 1: rate = 1.3; break;
    case 2: rate = 1.5; break;
    case 3: rate = 1.6; break;
    case 5: rate = 1.85; break;
    case 10: rate = 2.0; break;
  }

  // Update hidden field so invest.php gets the right rate
  document.getElementById('rate').value = rate;

  // Show profit preview
  const profit = amount * rate;
  document.getElementById('profit').textContent = profit.toFixed(2) + ' KES';
}



// INVEST FORM INTERCEPT
document.getElementById('investForm')?.addEventListener('submit', function (e) {
  if (!window.userHasPackage) {
    e.preventDefault();
    alert("You need a Service Package to make an Investment.");
  }
});


//WITHDRAW SECTION

// Hide token field initially
const tokenField = document.getElementById('tokenField');
const tokInput = document.getElementById('tokCode');
tokenField.style.display = 'none';
tokInput.removeAttribute('required');

// Toggle token visibility and requirement
document.getElementById('witSource').addEventListener('change', function () {
  const val = this.value;
  const needsToken = ['cashback', 'whatsapp', 'invested'].includes(val);

  if (needsToken) {
    tokenField.style.display = 'block';
    tokInput.setAttribute('required', 'required');
  } else {
    tokenField.style.display = 'none';
    tokInput.removeAttribute('required');
    tokInput.value = ''; // clear token if previously entered
  }
});

// Strict numeric enforcement for phone inputs
['phoneNo', 'witphoneNo'].forEach(id => {
  const input = document.getElementById(id);
  if (!input) return;

  input.addEventListener('input', function () {
    // Strip any non-digit characters (letters, symbols, etc.)
    this.value = this.value.replace(/\D/g, '');

    // Limit to 10 digits
    if (this.value.length > 10) {
      this.value = this.value.slice(0, 10);
    }
  });
});


document.getElementById('witForm').addEventListener('submit', function (e) {
  if (!window.userHasPackage) {
    e.preventDefault();
    alert("You need a Service Package to Withdraw.");
    return;
  }
  const phone = document.getElementById('witphoneNo').value;
  if (!/^\d{10}$/.test(phone)) {
    e.preventDefault();
    alert('Please enter a valid 10-digit phone number.');
  }
});


//TRANSACTION SECTION

var transSwiper = new Swiper("#transSwiper", {
  effect: "coverflow",
  grabCursor: true,
  centeredSlides: true,
  loop: true,
  initialSlide: 2,
  slidesPerView: "auto",
  coverflowEffect: {
    rotate: 0,
    stretch: 0,   // <- reduce or set to 0
    depth: 250,
    modifier: 1,
    slideShadows: false, // less movement illusion
  },
  on: {
    click(event) {
      const swiper = this;
      if (swiper.clickedSlide) {
        const realIndex = swiper.clickedSlide.getAttribute('data-swiper-slide-index');
        swiper.slideToLoop(realIndex);
      }
    },
  },
  pagination: {
    el: ".swiper-pagination",
    clickable: true,
  },
});


//WHATSAPP SECTION

const apiPrefix = window.location.pathname.includes('/admin/') ? '../' : '';

document.addEventListener("DOMContentLoaded", () => {
  loadWhatsappUploads(); // Load persistent uploads
  fetch(apiPrefix + "fetch_daily_product.php")
    .then(res => res.json())
    .then(data => {
      if (data.status !== "success") return;

      const img = document.getElementById("uploadedImage");
      const downloadBtn = document.getElementById("downloadButton");

      // SERVICE PACKAGE PURCHASE LOGIC
      // Use Event Delegation to handle clicks even inside Swiper clones
      document.body.addEventListener('click', function (e) {
        const btn = e.target.closest('.service_pkg_price');
        if (btn) {
          e.preventDefault();
          const selectedPackage = btn.getAttribute("data-package");
          const selectedAmount = btn.getAttribute("data-amount");

          if (selectedPackage && selectedAmount) {
            const modal = document.getElementById("confirmModal");
            const confirmMsg = document.getElementById("confirmMsg");
            const btnYes = document.getElementById("confirmYes");

            // Setup Modal
            confirmMsg.innerText = `Are you sure you want to purchase ${selectedPackage} for ${selectedAmount} KES?`;
            modal.style.display = "block";

            // Setup Yes Button
            // Note: simple onclick overwrite prevents listener stacking
            if (btnYes) {
              btnYes.onclick = function () {
                const formData = new FormData();
                formData.append("package_name", selectedPackage);
                formData.append("amount", selectedAmount);

                modal.style.display = "none";

                fetch(apiPrefix + "buy_package.php", {
                  method: "POST",
                  body: formData
                })
                  .then(res => res.json())
                  .then(data => {
                    if (data.status === "success") {
                      if (typeof showPopup === "function") {
                        showPopup("Purchase Successful! Reloading...", "success");
                      } else {
                        alert("Purchase Successful!");
                      }
                      setTimeout(() => location.reload(), 2000);
                    } else {
                      if (typeof showPopup === "function") {
                        showPopup(data.message, "error");
                      } else {
                        alert("Error: " + data.message);
                      }
                    }
                  })
                  .catch(err => {
                    console.error(err);
                    alert("An unexpected error occurred.");
                  });
              };
            }

            // Setup No Button
            const btnNo = document.getElementById("confirmNo");
            if (btnNo) {
              btnNo.onclick = () => {
                modal.style.display = "none";
              }
            };
          }
        }
      });

      if (!img || !downloadBtn) return;

      img.src = apiPrefix + data.image_url;
      img.style.display = "block";

      downloadBtn.style.display = "inline-block";
      downloadBtn.onclick = () => {
        const a = document.createElement("a");
        a.href = data.image_url;
        a.download = data.image_url.split("/").pop();
        document.body.appendChild(a);
        a.click();
        a.remove();
      };
    })
    .catch(err => console.error(err));
});

//ADMIN DAILY PRODUCT UPLOAD

const uploadForm = document.getElementById("upload-form");

if (uploadForm) {
  uploadForm.addEventListener("submit", e => {
    e.preventDefault();

    const fileInput = document.getElementById("productImage");
    if (!fileInput || !fileInput.files.length) {
      alert("Select an image");
      return;
    }

    const formData = new FormData();
    formData.append("productImage", fileInput.files[0]);
    formData.append("ajax", "1");

    fetch(apiPrefix + "whatsapp_product_upload.php", {
      method: "POST",
      body: formData
    })
      .then(res => res.text().then(text => {
        try {
          return JSON.parse(text);
        } catch (e) {
          console.error("Server response:", text);
          throw new Error("Server returned non-JSON response. Check console for details.");
        }
      }))
      .then(data => {
        if (data.status === "success") {
          const img = document.getElementById("uploadedImage");
          const downloadBtn = document.getElementById("downloadButton");

          if (img) {
            img.src = data.image_url;
            img.style.display = "block";
          }
          if (downloadBtn) downloadBtn.style.display = "inline-block";

          alert("Daily product updated successfully");
        } else {
          alert("Upload failed: " + (data.message || "Unknown error"));
        }
      })
      .catch(err => {
        console.error(err);
        alert("Error: " + err.message);
      });
  });
}

//ADMIN PRODUCT IMAGE PREVIEW

document.getElementById("productImage")?.addEventListener("change", e => {
  const file = e.target.files[0];
  if (!file || !file.type.startsWith("image/")) {
    alert("Please select a valid image");
    return;
  }

  const reader = new FileReader();
  reader.onload = ev => {
    const img = document.getElementById("uploadedImage");
    if (!img) return;
    img.src = ev.target.result;
    img.style.display = "block";
  };
  reader.readAsDataURL(file);
});

//CALCULATE YOU'LL RECEIVE

document.getElementById("viewsInput")?.addEventListener("input", function () {
  const views = parseInt(this.value) || 0;
  const rate = 150;
  document.getElementById("receive").textContent = (views * rate).toFixed(2);
});

//UPLOAD WHATSAPP EARNING FILE

document.getElementById("uploadNowButton")?.addEventListener("click", e => {
  e.preventDefault();

  const fileInput = document.getElementById("earnFileInput");
  const views = parseInt(document.getElementById("viewsInput")?.value) || 0;
  const phone = document.querySelector('input[placeholder="Your Phone"]')?.value || "";
  const amount = views * 150;

  if (!window.userHasPackage) {
    alert("You need a Service Package to Earn from Uploads.");
    return;
  }

  if (!fileInput || !fileInput.files.length) {
    alert("Please select a file");
    return;
  }

  if (views <= 0) {
    alert("Enter valid views");
    return;
  }

  const formData = new FormData();
  formData.append("file", fileInput.files[0]);
  formData.append("views", views);
  formData.append("amount", amount);
  formData.append("phone", phone);

  fetch(apiPrefix + "whatsapp_upload.php", {
    method: "POST",
    body: formData
  })
    .then(res => res.json())
    .then(data => {
      if (data.status === "success") {
        alert("Submission recorded! +KES " + amount);

        addWhatsappUpload(
          data.filename,
          amount,
          data.created_at
        );

        loadWhatsappTransactions();

        fileInput.value = "";
        document.getElementById("viewsInput").value = "";
        document.getElementById("receive").textContent = "0";
      } else {
        alert(data.message);
      }
    })
    .catch(err => console.error(err));
});

//DISPLAY USER UPLOAD

function loadWhatsappUploads() {
  fetch(apiPrefix + "fetch_whatsapp_uploads.php")
    .then(res => res.json())
    .then(data => {
      const list = document.getElementById("uploadsList");
      if (!list) return;
      list.innerHTML = ""; // Clear current

      if (Array.isArray(data)) {
        data.forEach(item => {
          addWhatsappUpload(item.filename, item.amount, item.created_at);
        });
      }
    })
    .catch(err => console.error("Error loading uploads:", err));
}

function addWhatsappUpload(filename, amount, createdAt) {
  const list = document.getElementById("uploadsList");
  if (!list) return;

  const row = document.createElement("div");
  row.className = "upload-row";

  const left = document.createElement("div");
  left.className = "upload-left";

  const link = document.createElement("a");
  link.className = "upload-link";
  link.href = apiPrefix + "whatsapp_uploads/" + filename;
  link.download = filename;
  link.textContent = filename;

  const time = document.createElement("div");
  time.className = "upload-sub";
  time.textContent = createdAt;

  left.appendChild(link);
  left.appendChild(time);

  const amt = document.createElement("div");
  amt.className = "upload-amount";
  amt.textContent = "+KES " + amount;

  row.appendChild(left);
  row.appendChild(amt);

  list.prepend(row);
}

//LOAD WHATSAPP TRANSACTIONS

function loadWhatsappTransactions() {
  fetch(apiPrefix + "fetch_whatsapp_transactions.php")
    .then(res => res.json())
    .then(data => {
      const container = document.getElementById("whatsappTransactions");
      if (!container) return;

      container.innerHTML = "";

      if (!data.length) {
        container.innerHTML = "<p>No WhatsApp transactions yet.</p>";
        return;
      }

      data.forEach(txn => {
        const row = document.createElement("div");
        row.className = "txn-row";

        row.innerHTML = `
                    <div class="txn-left">
                        <strong>+KES ${txn.amount}</strong>
                        <span>${txn.description}</span>
                    </div>
                    <div class="txn-right">${txn.created_at}</div>
                `;

        container.appendChild(row);
      });
    })
    .catch(err => console.error(err));
}





//FOREX SECTION
const forexBtn = document.getElementById("forexSignals");

if (forexBtn) {
  forexBtn.addEventListener("click", (e) => {
    e.preventDefault(); // Always prevent default first

    // 1. Basic Package Check
    if (!window.userHasPackage) {
      alert("You need a Service Package to access Forex Signals.");
      return;
    }

    // 2. Specific Level Check (Deluxe or Grand)
    const pkg = window.userPackageName || "";
    if (!pkg.includes("Deluxe") && !pkg.includes("Grand")) {
      alert("Restricted Access: You need a Deluxe or Grand Membership to subscribe to Forex Signals.");
      return;
    }

    // 3. Confirmation
    const modal = document.getElementById("confirmModal");
    const confirmMsg = document.getElementById("confirmMsg");
    const btnYes = document.getElementById("confirmYes");
    const btnNo = document.getElementById("confirmNo");

    confirmMsg.innerText = "Purchase Forex Signals for 5,000 KES?";
    modal.style.display = "block";

    // 4. Handle "Yes"
    const newYes = btnYes.cloneNode(true);
    btnYes.parentNode.replaceChild(newYes, btnYes);

    newYes.addEventListener("click", () => {
      modal.style.display = "none";

      // Call Backend
      fetch(apiPrefix + "buy_forex.php", {
        method: "POST"
      })
        .then(res => res.json())
        .then(data => {
          if (data.status === "success") {
            alert("Purchase Successful! Redirecting...");
            window.location.href = "https://www.fxtm.com/trading-tools/trading-signals/?utm_source=google&utm_medium=cpc&utm_content=181035816842&utm_term=&utm_campaign=%5BPMG%5D%5BRabbit%5D%5Bbrd:FXTM%5D%5Btgt:DSA%5D%5Bini:BAU%5D%5Bcou:KE%5D%5Blng:EN%5D%5Bchn:PPC%5D%5Bplt:Gogl%5D%5Bstr:GEN+PRSP%5D%5Bopt:pLTV%5D%5Bcjs:NUD%5D%5Blbl:VAL%5D%5BCT:Search%5D%5Bgrp:Convert+%7C+Paid+Search%5D&position=&info=cad_22554963541|gid_181035816842|bid_751885681334|tid_dsa-19959388920&matchtype=&device=c_&geo=9070318&cq_src=google_ads&cq_cmp=22554963541&cq_term=&cq_plac=&cq_net=g&cq_plt=gp&gclsrc=aw.ds&gad_source=1&gad_campaignid=22554963541&gbraid=0AAAAAC3ROqmyaARsnIQKn4D4OqIG9lOa4&gclid=CjwKCAiAt8bIBhBpEiwAzH1w6XK-GzFBaMI5ImiFqusZMzpcaZK9K5oI0nBeIybGUyImQqCk7fErURoCCD4QAvD_BwE;";
          } else {
            alert("Error: " + data.message);
          }
        })
        .catch(err => {
          console.error(err);
          alert("An error occurred during purchase.");
        });
    });

    // 5. Handle "No"
    const newNo = btnNo.cloneNode(true);
    btnNo.parentNode.replaceChild(newNo, btnNo);

    newNo.addEventListener("click", () => {
      modal.style.display = "none";
    });

  });
}


//AVIATOR SECTION
const aviatorBtn = document.getElementById("downloadAviator");

if (aviatorBtn) {
  aviatorBtn.addEventListener("click", (e) => {
    e.preventDefault(); // Always prevent default first

    // 1. Basic Package Check
    if (!window.userHasPackage) {
      alert("You need a Service Package to access the Aviator Predictor.");
      return;
    }

    // 2. Specific Level Check (Deluxe or Grand)
    const pkg = window.userPackageName || "";
    if (!pkg.includes("Deluxe") && !pkg.includes("Grand")) {
      alert("Restricted Access: You need a Deluxe or Grand Membership to download the Aviator Bot.");
      return;
    }

    // 3. Confirmation
    const modal = document.getElementById("confirmModal");
    const confirmMsg = document.getElementById("confirmMsg");
    const btnYes = document.getElementById("confirmYes");
    const btnNo = document.getElementById("confirmNo");

    confirmMsg.innerText = "Purchase Aviator Bot for 5,000 KES?";
    modal.style.display = "block";

    // 4. Handle "Yes"
    // Remove old listeners to prevent stacking (simple robust method)
    const newYes = btnYes.cloneNode(true);
    btnYes.parentNode.replaceChild(newYes, btnYes);

    newYes.addEventListener("click", () => {
      modal.style.display = "none";

      // Call Backend
      fetch(apiPrefix + "buy_aviator.php", {
        method: "POST"
      })
        .then(res => res.json())
        .then(data => {
          if (data.status === "success") {
            alert("Purchase Successful! Redirecting...");
            window.location.href = "https://www.aviatorgame.net/predictor/";
          } else {
            alert("Error: " + data.message);
          }
        })
        .catch(err => {
          console.error(err);
          alert("An error occurred during purchase.");
        });
    });

    // 5. Handle "No"
    // Also clone/replace to clean up previous listeners
    const newNo = btnNo.cloneNode(true);
    btnNo.parentNode.replaceChild(newNo, btnNo);

    newNo.addEventListener("click", () => {
      modal.style.display = "none";
    });

  });
}



//SERVICE PACKAGE SECTION

var pkgSwiper = new Swiper("#pkgswiper", {
  effect: "cards",
  grabCursor: true,
  loop: true,
  initialSlide: 2,
  rotate: true,
  mousewheel: {
    invert: false,
  },
  pagination: {
    el: ".swiper-pagination",
    clickable: true,
  },

  on: {
    slideChange: function () {
      const fixedIndex = this.realIndex % 4; // normalize index to 0–3
      updatePkgText(fixedIndex);
    },

    click: function () {
      this.slideToLoop(this.clickedIndex, 300); // true looping
    }
  }
});

// Update Text Function
function updatePkgText(index) {
  const textBlocks = [
    ".elitetext",
    ".prestigetext",
    ".deluxetext",
    ".grandtext"
  ];

  // Hide all first
  document.querySelectorAll(".elitetext, .prestigetext, .deluxetext, .grandtext")
    .forEach(el => {
      el.style.display = "none";
      el.classList.remove("pkgTextActive");
    });

  // Show correct text
  const block = document.querySelector(textBlocks[index]);
  if (block) {
    block.style.display = "flex";
    block.classList.add("pkgTextActive");
  }
}




//TOKEN SECTION

var tokenSwiper = new Swiper("#tokenswiper", {
  effect: "coverflow",
  grabCursor: true,
  centeredSlides: true,
  loop: true,
  initialSlide: 2,
  slidesPerView: "auto",
  coverflowEffect: {
    rotate: 0,
    stretch: 0,   // <- reduce or set to 0
    depth: 250,
    modifier: 1,
    slideShadows: false, // less movement illusion
  },
  on: {
    click(event) {
      const swiper = this;
      if (swiper.clickedSlide) {
        const realIndex = swiper.clickedSlide.getAttribute('data-swiper-slide-index');
        swiper.slideToLoop(realIndex);
      }
    },
  },
  pagination: {
    el: ".swiper-pagination",
    clickable: true,
  },
});


//MY TEAM SECTION

// Data: your team rows
// Load Team Data from Backend
function loadMyTeam() {
  fetch(apiPrefix + "fetch_team.php")
    .then(res => res.json())
    .then(d => {
      if (d.status === "success") {
        renderTable(d.data);
      } else {
        console.error("Failed to load team:", d.message);
        document.getElementById('team-body').innerHTML = `<tr><td colspan="6" style="text-align:center;">${d.message}</td></tr>`;
      }
    })
    .catch(err => console.error("Error loading team:", err));
}

// Helpers
function membershipBadge(label) {
  if (!label || label === 'NO PACKAGE') return '<span class="badge" style="background:#555;">None</span>';
  const type = /prestige/i.test(label) ? 'prestige' : (/grand/i.test(label) ? 'grand' : (/deluxe/i.test(label) ? 'deluxe' : 'elite'));
  const text = label.replace(/membership/i, '').trim();
  return `<span class="badge badge--${type}" title="${label}">${text}</span>`;
}

function createRow(item) {
  return `
      <tr data-rank="${item.rank}" data-name="${item.name}">
        <td>${item.rank}</td>
        <td>${item.name}</td>
        <td>${item.email}</td>
        <td class="phone">${item.phone}</td>
        <td class="deposit">${item.deposit}</td>
        <td>${membershipBadge(item.membership)}</td>
        <td>${item.ref_date || '-'}</td>
        <td style="text-transform: capitalize; color: ${item.status === 'paid' ? 'green' : 'orange'}; font-weight:bold;">${item.status}</td>
        <td>
           <!-- Actions removed for regular user -->
           <span style="color: #ccc; font-size: 12px;">View Only</span>
        </td>
      </tr>
    `;
}

function renderTable(data) {
  const tbody = document.getElementById('team-body');
  if (!data.length) {
    tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;">No team members yet.</td></tr>';
    return;
  }
  tbody.innerHTML = data.map(createRow).join('');
}

// Initialize
loadMyTeam();


// TOKEN PURCHASE SECTION

// TOKEN PURCHASE SECTION
// Use Event Delegation to handle clicks on .tokprice buttons (even inside Swiper duplicates)
document.body.addEventListener("click", function (e) {
  if (e.target && e.target.classList.contains("tokprice")) {
    e.preventDefault();
    const btn = e.target;

    const name = btn.getAttribute("data-package");
    const amount = btn.getAttribute("data-amount");

    // Confirm
    const modal = document.getElementById("confirmModal");
    const confirmMsg = document.getElementById("confirmMsg");
    const btnYes = document.getElementById("confirmYes");
    const btnNo = document.getElementById("confirmNo");

    confirmMsg.innerText = `Buy ${name} for ${amount} KES?`;
    modal.style.display = "block";

    // Remove old listeners by cloning
    const newYes = btnYes.cloneNode(true);
    btnYes.parentNode.replaceChild(newYes, btnYes);

    newYes.addEventListener("click", (e) => {
      e.preventDefault(); // Stop any default form submission
      modal.style.display = "none";

      fetch(apiPrefix + "buy_token.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: `token_name=${encodeURIComponent(name)}&amount=${amount}`
      })
        .then(r => r.text())
        .then(text => {
          try {
            return JSON.parse(text);
          } catch (e) {
            throw new Error("Invalid JSON: " + text);
          }
        })
        .then(d => {
          if (d.status === "success") {
            // Show Custom Success Modal
            const tokenModal = document.getElementById('tokenSuccessModal');
            const codeDisplay = document.getElementById('generatedTokenCode');
            const successMsg = document.getElementById('tokenSuccessMsg');

            if (tokenModal && codeDisplay) {
              codeDisplay.innerText = d.token_code || "ERROR";
              successMsg.innerText = `You have successfully purchased ${d.token_name || 'Token'}.`;
              tokenModal.style.display = "block";

              // Copy Logic
              const copyBtn = document.getElementById('copyTokenBtn');
              const copyFeedback = document.getElementById('copyFeedback');
              if (copyBtn) {
                const newCopy = copyBtn.cloneNode(true);
                copyBtn.parentNode.replaceChild(newCopy, copyBtn);

                newCopy.addEventListener('click', () => {
                  navigator.clipboard.writeText(d.token_code).then(() => {
                    copyFeedback.style.display = "block";
                    setTimeout(() => copyFeedback.style.display = "none", 2000);
                  }).catch(err => {
                    alert("Failed to copy. Please copy manually.");
                  });
                });
              }
            } else {
              // Fallback: Alert only, NO RELOAD
              alert("Success! Code: " + d.token_code);
            }

          } else {
            alert("Error: " + d.message);
          }
        })
        .catch(err => {
          console.error(err);
          alert("Request failed. Check console.");
        });
    });

    const newNo = btnNo.cloneNode(true);
    btnNo.parentNode.replaceChild(newNo, btnNo);
    newNo.addEventListener("click", () => {
      modal.style.display = "none";
    });
  }
});



// WITHDRAWAL SUBMISSION
const witForm = document.querySelector("#withdrawal form"); // Targeting the form inside #withdrawal section
if (witForm) {
  witForm.addEventListener("submit", (e) => {
    e.preventDefault();

    const walletSelect = witForm.querySelector("select");
    const tokenInput = witForm.querySelector("input[name='tokCode']");
    const amountInput = witForm.querySelector("input[name='amount']");

    const wallet = walletSelect.value;
    const code = tokenInput ? tokenInput.value : '';
    const amount = amountInput.value;

    if (!wallet) {
      alert("Please select a wallet.");
      return;
    }

    fetch(apiPrefix + "process_withdrawal.php", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: `wallet_type=${wallet}&token=${code}&amount=${amount}`
    })
      .then(r => r.json())
      .then(d => {
        if (d.status === "success") {
          showPopup(d.message, "success");
          setTimeout(() => location.reload(), 2000);
        } else {
          alert("Withdrawal Failed: " + d.message);
        }
      })
      .catch(err => {
        console.error(err);
        alert("Network error.");
      });
  });
}

// Copy Referral Link
function updateReferralLink() {
  const myLinkEl = document.getElementById("myLink");
  if (myLinkEl && typeof USERNAME !== 'undefined') {
    let baseUrl;
    const currentUrl = window.location.href;
    const pathWithoutFile = currentUrl.substring(0, currentUrl.lastIndexOf('/'));

    if (window.location.pathname.includes('/admin/')) {
      // In admin (e.g. .../public/admin), go up one level to public
      baseUrl = pathWithoutFile.substring(0, pathWithoutFile.lastIndexOf('/'));
    } else {
      // In public (e.g. .../public), use as is
      baseUrl = pathWithoutFile;
    }

    myLinkEl.innerText = `${baseUrl}/index.php?ref=${USERNAME}`;
  }
}

// Run on load
updateReferralLink();

function copyMyLink() {
  const linkText = document.getElementById("myLink").innerText;
  navigator.clipboard.writeText(linkText).then(() => {
    const feedback = document.getElementById("copyMsg");
    if (feedback) {
      feedback.style.display = "inline";
      setTimeout(() => feedback.style.display = "none", 2000);
    }
  }).catch(err => {
    console.error('Failed to copy: ', err);
  });
}
