// public/js/transactions.js

async function loadTransactions() {
    const apiPrefix = window.location.pathname.includes('/admin/') ? '../' : '';
    try {
        const res = await fetch(apiPrefix + 'transactions/get_transactions.php');
        const data = await res.json();

        console.log('Transactions data:', data);

        // Helper to render or show fallback
        function renderList(elementId, records, formatter) {
            const el = document.getElementById(elementId);
            if (!el) return;
            el.innerHTML = '';
            if (!records || records.length === 0) {
                el.innerHTML = '<p>No records yet.</p>';
                return;
            }
            records.forEach(tx => {
                el.innerHTML += formatter(tx);
            });
        }

        // Deposit Transactions
        renderList('depotransList', data.deposit, tx => {
            const dateObj = new Date(tx.created_at);
            const time = dateObj.toLocaleTimeString('en-KE', { hour: '2-digit', minute: '2-digit', hour12: true });
            const date = dateObj.toLocaleDateString('en-KE', { weekday: 'short', day: 'numeric', month: 'short' });
            const statusClass = tx.status === 'success' ? 'deposit-status-success' : 'deposit-status-failed';

            return `
                <div class="deposit-card">
                    <div class="deposit-details">
                        <div class="deposit-left">
                            <div class="deposit-amount ${statusClass}">KES ${parseFloat(tx.amount).toFixed(2)}</div>
                            <div class="deposit-time">${time} – ${date}</div>
                        </div>
                        <div class="deposit-right">
                            <div class="deposit-ref">${tx.mpesa_ref}</div>
                            <div class="deposit-status ${statusClass}">${tx.status.charAt(0).toUpperCase() + tx.status.slice(1)}</div>
                        </div>
                    </div>
                </div>
            `;
        });


        // Service Package Transactions
        console.log('Service Purchase Data:', data.service_purchase);
        renderList('serviceList', data.service_purchase, tx => {
            const dateObj = new Date(tx.created_at);
            const time = dateObj.toLocaleTimeString('en-KE', { hour: '2-digit', minute: '2-digit', hour12: true });
            const date = dateObj.toLocaleDateString('en-KE', { weekday: 'short', day: 'numeric', month: 'short' });
            // User requested status "Confirmed"
            const displayStatus = tx.status === 'success' ? 'Confirmed' : tx.status;
            const statusClass = tx.status === 'success' ? 'trans-status-success' : 'trans-status-failed';

            return `
                <div class="trans-card">
                    <div class="trans-details">
                        <div class="trans-left">
                            <div class="trans-amount ${statusClass}">KES ${parseFloat(tx.amount).toFixed(2)}</div>
                            <div class="trans-time">${time} – ${date}</div>
                        </div>
                        <div class="trans-right">
                            <div class="trans-ref">${tx.mpesa_ref}</div>
                            <div class="trans-status ${statusClass}">${displayStatus}</div>
                        </div>
                    </div>
                </div>
            `;
        });

        // Deposits
        renderList('depoList', data.deposit, tx => {
            const dateObj = new Date(tx.created_at);
            const time = dateObj.toLocaleTimeString('en-KE', { hour: '2-digit', minute: '2-digit', hour12: true });
            const date = dateObj.toLocaleDateString('en-KE', { weekday: 'short', day: 'numeric', month: 'short' });
            const statusClass = tx.status === 'success' ? 'trans-status-success' : 'trans-status-failed';

            return `
                <div class="trans-card">
                    <div class="trans-details">
                        <div class="trans-left">
                            <div class="trans-amount ${statusClass}">+KES ${parseFloat(tx.amount).toFixed(2)}</div>
                            <div class="trans-time">${time} – ${date}</div>
                        </div>
                        <div class="trans-right">
                            <div class="trans-ref">${tx.mpesa_ref}</div>
                            <div class="trans-status ${statusClass}">${tx.status.charAt(0).toUpperCase() + tx.status.slice(1)}</div>
                        </div>
                    </div>
                </div>
            `;
        });

        // Investments (Capital) - Fetch from new dedicated endpoint
        fetch(apiPrefix + 'fetch_capital_history.php')
            .then(r => r.json())
            .then(capitalData => {
                renderList('capitalList', capitalData, tx => {
                    const dateObj = new Date(tx.created_at);
                    const time = dateObj.toLocaleTimeString('en-KE', { hour: '2-digit', minute: '2-digit', hour12: true });
                    const date = dateObj.toLocaleDateString('en-KE', { weekday: 'short', day: 'numeric', month: 'short' });

                    const isMatured = tx.status === 'Matured';
                    const amountClass = isMatured ? 'trans-status-return' : 'trans-status-principal';

                    // Format Reference
                    // If matured: "After X days"
                    // If verified: "X days"
                    let refText = tx.days + " days";
                    if (isMatured) {
                        refText = "After " + refText;
                    }

                    return `
                        <div class="trans-card">
                            <div class="trans-details">
                                <div class="trans-left">
                                    <div class="trans-amount ${amountClass}">${tx.prefix}KES ${parseFloat(tx.amount).toFixed(2)}</div>
                                    <div class="trans-time">${time} – ${date}</div>
                                </div>
                                <div class="trans-right">
                                    <div class="trans-ref">${refText}</div>
                                    <div class="trans-status ${amountClass}">${tx.status}</div>
                                </div>
                            </div>
                        </div>
                    `;
                });
            })
            .catch(e => console.error("Capital load error:", e));


        // WhatsApp Transactions
        renderList('whatsappList', data.whatsapp, tx => {
            const dateObj = new Date(tx.created_at);
            const time = dateObj.toLocaleTimeString('en-KE', { hour: '2-digit', minute: '2-digit', hour12: true });
            const date = dateObj.toLocaleDateString('en-KE', { weekday: 'short', day: 'numeric', month: 'short' });

            // WhatsApp earnings are always credits
            const statusClass = tx.status === 'success' ? 'trans-status-success' : 'trans-status-failed';

            // Show number of views in reference column
            const views = tx.views || 0; // backend should send this field
            const ref = `${views} views`;

            return `
                <div class="trans-card">
                    <div class="trans-details">
                        <div class="trans-left">
                            <div class="trans-amount ${statusClass}">+KES ${parseFloat(tx.amount).toFixed(2)}</div>
                            <div class="trans-time">${time} – ${date}</div>
                        </div>
                        <div class="trans-right">
                            <div class="trans-ref">${ref}</div>
                            <div class="trans-status ${statusClass}">${tx.status}</div>
                        </div>
                    </div>
                </div>
            `;
        });


        // Cashback
        renderList('cashbackList', data.cashback, tx => {
            const dateObj = new Date(tx.created_at);
            const time = dateObj.toLocaleTimeString('en-KE', { hour: '2-digit', minute: '2-digit', hour12: true });
            const date = dateObj.toLocaleDateString('en-KE', { weekday: 'short', day: 'numeric', month: 'short' });

            return `
                <div class="trans-card">
                    <div class="trans-details">
                        <div class="trans-left">
                            <div class="trans-amount trans-status-success">+KES ${parseFloat(tx.amount).toFixed(2)}</div>
                            <div class="trans-time">${time} – ${date}</div>
                        </div>
                        <div class="trans-right">
                            <div class="trans-ref">${tx.mpesa_ref || 'N/A'}</div>
                            <div class="trans-status trans-status-success">Credited</div>
                        </div>
                    </div>
                </div>
            `;
        });

        // Aviator
        renderList('aviatorList', data.aviator, tx => {
            const dateObj = new Date(tx.created_at);
            const time = dateObj.toLocaleTimeString('en-KE', { hour: '2-digit', minute: '2-digit', hour12: true });
            const date = dateObj.toLocaleDateString('en-KE', { weekday: 'short', day: 'numeric', month: 'short' });

            return `
                <div class="trans-card">
                    <div class="trans-details">
                        <div class="trans-left">
                            <div class="trans-amount trans-status-principal">-KES ${parseFloat(Math.abs(tx.amount)).toFixed(2)}</div>
                            <div class="trans-time">${time} – ${date}</div>
                        </div>
                        <div class="trans-right">
                            <div class="trans-ref">${tx.mpesa_ref || 'N/A'}</div>
                            <div class="trans-status trans-status-return">Played</div>
                        </div>
                    </div>
                </div>
            `;
        });

        // Forex
        renderList('forexList', data.forex, tx => {
            const dateObj = new Date(tx.created_at);
            const time = dateObj.toLocaleTimeString('en-KE', { hour: '2-digit', minute: '2-digit', hour12: true });
            const date = dateObj.toLocaleDateString('en-KE', { weekday: 'short', day: 'numeric', month: 'short' });

            return `
                <div class="trans-card">
                    <div class="trans-details">
                        <div class="trans-left">
                            <div class="trans-amount trans-status-principal">-KES ${parseFloat(Math.abs(tx.amount)).toFixed(2)}</div>
                            <div class="trans-time">${time} – ${date}</div>
                        </div>
                        <div class="trans-right">
                            <div class="trans-ref">${tx.mpesa_ref || 'N/A'}</div>
                            <div class="trans-status trans-status-return">Trade</div>
                        </div>
                    </div>
                </div>
            `;
        });

        // Affiliates
        renderList('affiliateList', data.affiliate, tx => {
            const dateObj = new Date(tx.created_at);
            const time = dateObj.toLocaleTimeString('en-KE', { hour: '2-digit', minute: '2-digit', hour12: true });
            const date = dateObj.toLocaleDateString('en-KE', { weekday: 'short', day: 'numeric', month: 'short' });

            return `
                <div class="trans-card">
                    <div class="trans-details">
                        <div class="trans-left">
                            <div class="trans-amount trans-status-success">+KES ${parseFloat(tx.amount).toFixed(2)}</div>
                            <div class="trans-time">${time} – ${date}</div>
                        </div>
                        <div class="trans-right">
                            <div class="trans-ref">${tx.ref || 'N/A'}</div>
                            <div class="trans-status trans-status-success">Payout</div>
                        </div>
                    </div>
                </div>
            `;
        });

        // Withdrawals
        renderList('withdrawList', data.withdrawal, tx => {
            const dateObj = new Date(tx.created_at);
            const time = dateObj.toLocaleTimeString('en-KE', { hour: '2-digit', minute: '2-digit', hour12: true });
            const date = dateObj.toLocaleDateString('en-KE', { weekday: 'short', day: 'numeric', month: 'short' });
            const statusClass = tx.status === 'success' ? 'trans-status-success' : 'trans-status-failed';

            return `
                <div class="trans-card">
                    <div class="trans-details">
                        <div class="trans-left">
                            <div class="trans-amount ${statusClass}">-KES ${parseFloat(tx.amount).toFixed(2)}</div>
                            <div class="trans-time">${time} – ${date}</div>
                        </div>
                        <div class="trans-right">
                            <div class="trans-ref">${tx.mpesa_ref}</div>
                            <div class="trans-status ${statusClass}">${tx.status.charAt(0).toUpperCase() + tx.status.slice(1)}</div>
                        </div>
                    </div>
                </div>
            `;
        });



    } catch (err) {
        console.error('Error loading transactions:', err);
    }
}

document.addEventListener('DOMContentLoaded', loadTransactions);
