<?php
// invest.php
session_start();
require_once __DIR__ . '/../backend/connect.php';
require_once __DIR__ . '/transactions/record_transaction.php';

// Validate logged-in user
if (!isset($_SESSION['user_id'])) {
    $_SESSION['auth_error'] = "Please log in to invest.";
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Check Service Package
$stmtPkg = $conn->prepare("SELECT package FROM users WHERE id = ?");
$stmtPkg->bind_param("i", $user_id);
$stmtPkg->execute();
$resPkg = $stmtPkg->get_result();
$uData = $resPkg->fetch_assoc();
if (empty($uData['package']) || $uData['package'] === 'NO PACKAGE') {
    echo json_encode(['status' => 'error', 'message' => 'You need a Service Package to satisfy this request.']);
    exit;
}
$stmtPkg->close();

// Inputs: amount, rate, days
$amount = isset($_POST['amount']) ? floatval($_POST['amount']) : 0;
$days   = isset($_POST['days']) ? intval($_POST['days']) : 0;

// Map days → rate on the server
$allowedDaysToRate = [
    1  => 1.30,
    2  => 1.50,
    3  => 1.60,
    5  => 1.85,
    10 => 2.00
];

$rate = $allowedDaysToRate[$days] ?? 0;

if ($amount <= 999 || $rate <= 0 || !isset($allowedDaysToRate[$days])) {
    $_SESSION['capital_error'] = "Invalid investment. Minimum Investment is Ksh. 1000.";
    header("Location: dashboard.php");
    exit();
}

// Fetch current deposit balance
$w = $conn->prepare("SELECT deposit_balance FROM wallets WHERE user_id = ? LIMIT 1");
$w->bind_param("i", $user_id);
$w->execute();
$wres = $w->get_result();
$wallet = $wres->fetch_assoc();
$w->close();

if (!$wallet) {
    $_SESSION['capital_error'] = "Wallet not found.";
    header("Location: dashboard.php");
    exit();
}

$deposit_balance = floatval($wallet['deposit_balance']);

// Insufficient funds check
if ($deposit_balance < $amount) {
    $_SESSION['capital_error'] = "Insufficient funds. Please deposit.";
    header("Location: dashboard.php");
    exit();
}

// Begin atomic operation
$conn->begin_transaction();

try {
    // Create investment record
    $i = $conn->prepare("INSERT INTO investments (user_id, amount, rate, duration_days, start_date, end_date, status)
                        VALUES (?, ?, ?, ?, CURDATE(), DATE_ADD(CURDATE(), INTERVAL ? DAY), 'active')");
    if (!$i) { throw new Exception($conn->error); }

    $i->bind_param("iddii", $user_id, $amount, $rate, $days, $days);
    if (!$i->execute()) { throw new Exception($i->error); }
    $i->close();

    // Deduct funds and record transaction via helper
    // This helper updates wallets (deposit_balance - amount, invested_capital + amount)
    // AND inserts into transactions table.
    $ref = "{$days}-day";
    record_transaction($conn, $user_id, 'investment_principal', $amount, 'system', 'success', $ref);

    $conn->commit();

    $_SESSION['capital_success'] = "Investment applied successfully!";
    
    // Redirect back to origin (admin or user dashboard)
    $redirect = $_SERVER['HTTP_REFERER'] ?? 'dashboard.php';
    header("Location: " . $redirect);
    exit();

} catch (Exception $e) {
    $conn->rollback();
    error_log("INVEST_TX_FAIL user={$user_id} amount={$amount} err=" . $e->getMessage());
    $_SESSION['capital_error'] = "Could not complete investment. Please try again.";
    
    // Redirect back to origin
    $redirect = $_SERVER['HTTP_REFERER'] ?? 'dashboard.php';
    header("Location: " . $redirect);
    exit();
}
