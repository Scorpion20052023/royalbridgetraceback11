<?php
/**
 * access_token.php
 * Fetches M-Pesa access token from Safaricom Daraja API
 */

function mpesa_access_token(): string {
    // Load credentials from environment variables
    $consumerKey    = getenv('MPESA_CONSUMER_KEY');
    $consumerSecret = getenv('MPESA_CONSUMER_SECRET');
    $env            = getenv('MPESA_ENV') ?: 'sandbox';

    // Choose endpoint based on environment
    $url = $env === 'production'
        ? 'https://api.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials'
        : 'https://sandbox.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials';

    // Encode credentials
    $credentials = base64_encode($consumerKey . ':' . $consumerSecret);

    // Initialize cURL
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Basic ' . $credentials
    ]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($ch);
    if (curl_errno($ch)) {
        throw new Exception('Token request error: ' . curl_error($ch));
    }
    curl_close($ch);

    // Decode response
    $data = json_decode($response, true);
    if (!isset($data['access_token'])) {
        throw new Exception('Failed to obtain access token: ' . $response);
    }

    return $data['access_token'];
}