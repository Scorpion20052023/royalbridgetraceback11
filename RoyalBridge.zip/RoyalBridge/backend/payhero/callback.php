<?php
require_once __DIR__ . '/../connect.php';

header("Content-Type: application/json");

// 1. Read incoming JSON
$raw = file_get_contents('php://input');
if (!$raw) {
    echo json_encode(["status" => "No content"]);
    exit;
}

// 2. Log for debugging
$logFile = __DIR__ . '/../../logs/payhero_callback.log';
$logEntry = date('Y-m-d H:i:s') . " - " . $raw . PHP_EOL . str_repeat('-', 20) . PHP_EOL;
file_put_contents($logFile, $logEntry, FILE_APPEND);

// 3. Decode
$data = json_decode($raw, true);

/*
  Example PayHero Callback Payload (hypothetical, based on standard structures):
  {
     "response": {
        "reference": "PH-...",
        "amount": 100,
        "status": "Success",  // or "Failed", "Cancelled"
        "result_code": 0,
        "phone_number": "2547..."
     }
  }
  
  Adjust parsing logic based on actual PayHero documentation.
  Let's assume the important fields are at the top level or nested in 'response'.
*/

$response = $data['response'] ?? $data;
$reference = $response['reference'] ?? $response['ExternalRef'] ?? null;
$status    = $response['status'] ?? 'Failed';
$amount    = $response['amount'] ?? 0;

if (!$reference) {
    echo json_encode(["status" => "No reference found"]);
    exit;
}

// 4. Update Database
if (strtolower($status) === 'success' || strtolower($status) === 'successful') {
    // Check if duplicate
    $check = $conn->prepare("SELECT id, status, user_id FROM mpesa_requests WHERE merchant_request_id = ? AND status != 'COMPLETED'");
    $check->bind_param("s", $reference);
    $check->execute();
    $res = $check->get_result();

    if ($row = $res->fetch_assoc()) {
        $reqId = $row['id'];
        $userId = $row['user_id'];

        // Mark completed
        $update = $conn->prepare("UPDATE mpesa_requests SET status = 'COMPLETED', updated_at = NOW() WHERE id = ?");
        $update->bind_param("i", $reqId);
        $update->execute();

        // Credit Wallet
        $wallet = $conn->prepare("UPDATE users SET balance = balance + ? WHERE id = ?");
        $wallet->bind_param("di", $amount, $userId);
        $wallet->execute();
        
        // Log transaction
        $desc = "Deposit via PayHero";
        $tx = $conn->prepare("INSERT INTO transactions (user_id, type, amount, description, created_at) VALUES (?, 'DEPOSIT', ?, ?, NOW())");
        $tx->bind_param("ids", $userId, $amount, $desc);
        $tx->execute();
    }
} else {
    // Mark failed
    $update = $conn->prepare("UPDATE mpesa_requests SET status = 'FAILED', updated_at = NOW() WHERE merchant_request_id = ?");
    $update->bind_param("s", $reference);
    $update->execute();
}

echo json_encode(["status" => "Received"]);
