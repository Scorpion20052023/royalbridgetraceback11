<?php
require_once __DIR__ . '/../connect.php';

function normalize_msisdn(string $phone): string {
    $p = preg_replace('/\D/', '', $phone);
    if (strpos($p, '254') === 0) return $p;
    if (strlen($p) === 10 && $p[0] === '0') return '254' . substr($p, 1);
    return $p;
}

function initiate_payhero_stk_push(mysqli $conn, int $userId, string $phone, int $amount, string $accountRef = 'RoyalBridge'): array {
    $endpoint = 'https://backend.payhero.co.ke/api/v2/payments';
    
    $apiUsername = getenv('PAYHERO_API_USERNAME');
    $apiPassword = getenv('PAYHERO_API_PASSWORD');
    $channelId   = getenv('PAYHERO_CHANNEL_ID');
    $callbackUrl = getenv('PAYHERO_CALLBACK_URL');
    
    // Some docs suggest Basic Auth with Username:Password, others might use the token directly.
    // Based on user input "Basic ...", we can use that header directly if provided, or construct it.
    $authToken = getenv('PAYHERO_AUTH_TOKEN');
    if (!$authToken) {
        $authToken = 'Basic ' . base64_encode("$apiUsername:$apiPassword");
    }

    $payload = [
        'amount'       => (float)$amount,
        'phone_number' => normalize_msisdn($phone),
        'channel_id'   => (int)$channelId,
        'provider'     => 'm-pesa',
        'external_reference' => $accountRef, // Or a unique transaction ID
        'callback_url' => $callbackUrl
    ];

    $ch = curl_init($endpoint);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Authorization: ' . $authToken
    ]);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
    $response = curl_exec($ch);
    
    if (curl_errno($ch)) {
        throw new Exception('Pay Hero request error: ' . curl_error($ch));
    }
    $data = json_decode($response, true);
    
    if (isset($data['status_code']) && $data['status_code'] >= 400) {
        throw new Exception($data['error_message'] ?? 'PayHero Request Failed');
    }

    if (isset($data['success']) && $data['success'] === false) {
         throw new Exception($data['message'] ?? 'PayHero Request Failed');
    }

    // Save initial request to DB
    // We might need a new table or adapt 'mpesa_requests'
    // For now, let's assume we reuse 'mpesa_requests' or create a similar record.
    // However, the fields might differ (CheckoutRequestID vs Pay Hero Reference).
    // Pay Hero returns a 'reference' or 'id'.
    
    $payHeroRef = $data['reference'] ?? $data['id'] ?? 'Unknown';
    $status = 'PENDING';

    // Adapting to existing schema: mpesa_requests (user_id, phone, amount, merchant_request_id, checkout_request_id, status)
    // We can put PayHero Ref in 'merchant_request_id' or 'checkout_request_id'
    
    $stmt = $conn->prepare(
        "INSERT INTO mpesa_requests (user_id, phone, amount, merchant_request_id, checkout_request_id, status)
         VALUES (?, ?, ?, ?, ?, ?)"
    );
    // using 'PAYHERO' as one ID to distinguish
    $systemRef = 'PAYHERO'; 
    $stmt->bind_param("isisss", $userId, $phone, $amount, $payHeroRef, $systemRef, $status);
    $stmt->execute();

    return $data;
}
