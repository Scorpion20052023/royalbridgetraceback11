# Pay Hero Deployment Checklist

Since you are testing locally ("localhost"), your website cannot receive confirmations (Callbacks) from Pay Hero yet. This means that while you receive the money, the user's dashboard balance won't update automatically.

**When you deploy to your live domain, you MUST follow these steps:**

## 1. Update the Callback URL
Open your `.env` file on the live server and update `PAYHERO_CALLBACK_URL` to your actual domain.

**File:** `config/.env`
```ini
# CHANGE THIS:
PAYHERO_CALLBACK_URL=https://your-domain.com/payhero_callback.php

# TO THIS (Example):
PAYHERO_CALLBACK_URL=https://www.royalbridge_investment.com/payhero_callback.php
```

## 2. Verify Database Connection
Ensure your database credentials in `backend/connect.php` or `config/.env` match your live database server.

## 3. Test a Live Deposit
1.  Sign up a test account on your live site.
2.  Deposit a small amount (e.g., 10 KES).
3.  **Critical Check:** Does the money appear in your Pay Hero wallet?
4.  **Critical Check:** Does the user's dashboard balance update automatically after ~10 seconds?

## Troubleshooting
If the balance doesn't update:
-   Check the file at `backend/payhero/callback.php`.
-   Check the error logs at `logs/payhero_callback.log` (if enabled in the script).
-   Ensure your server is not blocking incoming POST requests to the callback file.
