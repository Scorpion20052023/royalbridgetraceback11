<?php
session_start();
require_once __DIR__ . '/../backend/connect.php';

if (isset($_POST['signup'])) {
    $username = trim($_POST['username']);
    $email    = trim($_POST['email']);
    $password = $_POST['password'];
    $phone    = trim($_POST['phone']);

    // Basic validation
    if (empty($username) || empty($email) || empty($password) || empty($phone)) {
        $_SESSION['reg_error'] = "All fields are required.";
        header("Location: index.php");
        exit;
    }

    // Check duplicates
    $stmt = $conn->prepare("SELECT id FROM users WHERE username=? OR email=? OR phone=?");
    $stmt->bind_param("sss", $username, $email, $phone);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $_SESSION['reg_error'] = "Username, email, or phone already taken.";
        header("Location: index.php");
        exit;
    }

    // Check for referrer
    $referrer_id = null;
    if (isset($_SESSION['referrer_code'])) {
        $refCode = $_SESSION['referrer_code'];
        // Lookup referrer ID (assuming username match)
        $stmtRef = $conn->prepare("SELECT id FROM users WHERE username = ? LIMIT 1");
        $stmtRef->bind_param("s", $refCode);
        $stmtRef->execute();
        $resRef = $stmtRef->get_result();
        if ($rowRef = $resRef->fetch_assoc()) {
            $referrer_id = $rowRef['id'];
        }
        $stmtRef->close();
    }

    // Insert new user with referrer_id
    $hash = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $conn->prepare("INSERT INTO users (username, email, password, phone, referrer_id) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssi", $username, $email, $hash, $phone, $referrer_id);

    if ($stmt->execute()) {
        // ✅ Get the new user's ID
        $newUserId = $stmt->insert_id;
        
        // Clear referrer session
        unset($_SESSION['referrer_code']);

        // ✅ Create wallet row with default values
        $walletStmt = $conn->prepare("
            INSERT INTO wallets (
                user_id,
                whatsapp_balance, whatsapp_withdrawn,
                total_withdrawn, account_balance, account_total,
                affiliate_withdrawn, affiliate_balance,
                cashback_withdrawn, cashback_balance,
                invested_capital, deposit_balance, total_deposits
            ) VALUES (
                ?, 0.00, 0.00,
                0.00, 0.00, 0.00,
                0.00, 0.00,
                0.00, 0.00,
                0.00, 0.00, 0.00
            )
        ");
        $walletStmt->bind_param("i", $newUserId);
        $walletStmt->execute();

        $_SESSION['reg_success'] = "Registration successful. You can log in now. Happy Profits";
    } else {
        $_SESSION['reg_error'] = "Registration failed. Please try again.";
    }

    header("Location: index.php");
    exit;
}
?>
